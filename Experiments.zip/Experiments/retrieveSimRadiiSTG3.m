function f=retrieveSimRadiiSTG3()
global simradiiSTG3
f=simradiiSTG3;