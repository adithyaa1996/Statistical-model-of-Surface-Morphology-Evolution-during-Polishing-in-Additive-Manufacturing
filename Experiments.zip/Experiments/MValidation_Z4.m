%% So where do we start from
% Stage0-stage1
% Step1: Initialise heights, read heights
% Step2: Apply modified dynamics
% Step3: Define the objective for the new height functions
% Step4: Find objective value

%% Initialise heights,read heights EN
setModelHeightsSTG1_parametric([sial1(1);1;1;sial1(2)]); %
setModelHeightsSTG2_parametric([sial5(1);1;1;sial5(2)]); % 
setModelHeightsSTG3_parametric([sial10(1);1;1;sial10(2)]); % Executed
%% Initialise heights,read heights SA
setModelHeightsSTG1_parametric([sial2(1);1;1;sial2(2)]); % 
setModelHeightsSTG2_parametric([sial6b(1);1;1;sial6b(2)]); % 
setModelHeightsSTG3_parametric([sial11(1);1;1;sial11(2)]); % Executed
%% Initialise heights,read heights SA+EN (10/90)
setModelHeightsSTG1_parametric([sial3(1);1;1;sial3(2)]); % 
setModelHeightsSTG2_parametric([sial7b(1);1;1;sial7b(2)]); % 
setModelHeightsSTG3_parametric([sial12(1);1;1;sial12(2)]); % Executed
%% Initialise heights,read heights SA+EN (30/70)
setModelHeightsSTG1_parametric([sial4(1);1;1;sial4(2)]); % 
setModelHeightsSTG2_parametric([sial8(1);1;1;sial8(2)]); %
setModelHeightsSTG3_parametric([sial13(1);1;1;sial13(2)]); % Executed

%% Different values (Replace)
% Solve for Entropy 
sial14=[9.7931;0.0028]; % sa 4.2430 klD 2.9862
% Solve for Del_SA
sial15=[3.0611;0.0002];% sa 2.2151 klD 3.9595
% Solve for convex comb SA and Entropy (10/90)
sial16=[2.5956;0.0022]; % sa 4.2121  klD 2.9870
% Solve for convex comb SA and Entropy (30/70)
sial17=[5.2017;0.0160]; % sa 2.2240 klD 3.4859 *** Edit later

%% Evaluate
[funcVal,heightsForSACalc]=evalObjectiveStage3To4V2_Z(sial17,1,1);
%%
setModelHeightsSTG1();
setModelHeightsSTG2();
setModelHeightsSTG3();
xta1=[4.7101;23.5887;6.5008;0.0070]; %(sa 2.2327 klD 3.8623)
[funcValUF,heightsForSACalcUF]=evalObjectiveStage3To4V2_2(xta1,1,1);
%% Ideas for experiment design
lb=[0.01;0.5;0.1;0.00001];
ub=[20;40;10;0.04];
ObjectiveFunction = @evalObjectiveStage3To4V2_2;
[xmin,fxmin]=simulatedAnnealingSolution(xsa33,ObjectiveFunction,lb,ub); 

%% Average Objective value
f11=zeros(20,1);klD=zeros(20,1);
for j=1:1:20
    disp(j);
    [f,h]=evalObjectiveStage3To4V2_Z(sial16,1,0);
    f11(j)=f;
    klD(j)=percentDivergence(datastage(:,5),max(h)-h,70,0.1);
end
f11=mean(f11); klD=mean(klD);
 
%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:3000
    disp(counter);
    lb=[1;0.00000001];
%     lb=[4;6;1;0.001];
    ub=[10;1];
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand(2,1);
    [fh,hh]=evalObjectiveStage3To4V2_Z(xrandom,0.3,0.7);
    
    if fh<min_val 
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%%

%% Plot overall
plot([5.9519 4.5928 3.1029 5.2017],[0.0067 0.0059 0.0026 0.0160])

%% Graphics module
figure;
germa66=max(heightsForSACalc)-heightsForSACalc;
% perform raid
germa66(germa66>7)=[];

cdf1=cdfplot(germa66);
color1=[0 0 0];
set(cdf1,'LineWidth',3.5,'LineStyle','-','color',color1); % Sigma Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,5));
% color2=[0.8500, 0.3250, 0.0980];
color2=[0 0 0];
set(cdf2,'LineWidth',3,'LineStyle','--','color',color2); % Data
xlabel('x','FontSize',18);
ylabel('Cumulative Probability','FontSize',18);

% set a text box
annotation('textbox', [0.5, 0.6, 0.1, 0.1], 'String', 'KLdiv = 3.49    \DeltaSa = 2.22','FontSize',16)

% hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Best Fit Parameters
% % hold on;
% lgd=legend('Simulation','Data');
% lgd.FontSize=18;
title('')
set(gca,'FontSize',14);
% yh=get(gca,'ylabel');
% p34=get(yh,'position');
% p34(1)=-0.4+p34(1);
% set(yh,'position',p34);

%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.3;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,5));
hist2.BinWidth=0.3;
hist2.Normalization='probability';

