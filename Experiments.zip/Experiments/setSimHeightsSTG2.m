function setSimHeightsSTG2()
% datastage=retrieveHeights();
% datastageInv=max(datastage)-datastage;
% xa1=[4.6959;19.5189;1.4134;0.0174];
% x3=[0.34;11.95;0.3;0.0057];
% x6=[0.18;11.95;1.1;0.0057];
% here's assuming the point being fed is a valid point

% perform simulation from stage1 to 2 using point
xe14=[5.6850;8.4008;8.7162;0.0142]; %0.2272
[h,r]=returnHeightsRadiiStg1To2(xe14);


% pd=fitdist(datastageInv(:,1)+0.000001,'Weibull');
global simradiiSTG2
simradiiSTG2=r(:,1500);
% N = size(Locations,1); 
global simheightsSTG2
simheightsSTG2=h(:,1500);
