function f=retrieveSimHeightsSTG2()
global simheightsSTG2
f=simheightsSTG2;

