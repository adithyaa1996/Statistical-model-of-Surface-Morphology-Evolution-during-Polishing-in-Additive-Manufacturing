function f=retrieveModelRadiiSTG3()
global modelradiiSTG3;
f=modelradiiSTG3;
