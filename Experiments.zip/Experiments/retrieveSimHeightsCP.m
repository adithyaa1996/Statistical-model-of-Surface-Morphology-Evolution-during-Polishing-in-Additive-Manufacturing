function f=retrieveSimHeightsCP()
global simheightsCP
f=simheightsCP;

