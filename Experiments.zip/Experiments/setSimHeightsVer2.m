function setSimHeightsVer2()
datastage=retrieveHeights();
datastageInv=max(datastage)-datastage;
pd=fitdist(datastageInv(:,1)+0.000001,'Weibull');
N=50;
global simheights
simheights=random(pd,N,1);