%%%%%%% Asperity network %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N = 50;
Force = 1;
Temp = 20*ones(N,1); 
T0 = Temp;
radii = ones(N,1)*0.5 + randn(N,1)*0.05; % initial radii distribution
heights = ones(N,1)*50+randn(N,1)*5; % initial height distribution
F = zeros(N,1); % Force carried by asperities
params = cell(1,2); 
E = 1; 
params{1}= E; % E
params{2}=0.01; % determines distance solution accuracy
alpha = 0.5; 
kappa_1 = 1000; 
sigma = 1; 
rho = 1;

%% place asperities on a 2D space
% rand('state',15)
max_x = 100; % space length, in meters
max_y = 100; % space width, in meters
x_pos_new = max_x*rand(N,1); % Draw random positions for network nodes (x component)
y_pos_new = max_y*rand(N,1); % Draw random positions for network nodes (y component)
p_r = 0; % rewiring probability
%%% network generation
graph_new = spalloc(N, N, 20);
distance = zeros(N,N);
for row = 1:N-1
    for column = row+1:N
        distance(row,column) = sqrt((x_pos_new(row)-x_pos_new(column)).^2 + (y_pos_new(row)-y_pos_new(column)).^2);
    end
end

%% initialize simulation
Time = 10; dt = 0.01;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon)); 
T(:,1) = Temp;
h = zeros(N,length(Horizon)); 
h(:,1) = heights;
r = zeros(N,length(Horizon)); 
r(:,1) = radii;
k = 2;
st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);

for t = dt:dt:Time
    d_critical = solve_for_d(Force,r(:,k-1),h(:,k-1),params);
    F = zeros(N,1);
    active_nodes = find(heights>d_critical); % load bearing asperities
    F(active_nodes) = (2/3)*E*sqrt(r(active_nodes,k-1)).*(h(active_nodes,k-1)-d_critical*ones(length(active_nodes),1)).^1.5; % force carried by each node. 
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha*(T(:,k-1)-T0) + kappa_1*F);
    h(:,k) = h(:,k-1) + dt*(-sigma*T(:,k-1).*F);
    r(:,k) = r(:,k-1) + dt*(rho*sigma*T(:,k-1).*F);
    
    % store
    st_d_crit(k-1) = d_critical;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

%% compute the xi distance and edge likelihood
xi = zeros(N,N,length(Horizon));
for row = 1:N
    for column = 1:N
        xi(row, column,:) = distance(row,column)-(r(row,:)+r(column,:));
    end
end
%% plots
% 1. height and radii change

figure
subplot(1,2,1)
for i = 1:1:N 
    plot(Horizon,h(i,:),'LineWidth',2)
    pub_fig;
    hold on
end
title('Height change dynamics of all 50 asperities')
xlabel('Time (1000 steps)')
ylabel('Height (um)')

subplot(1,2,2)
for i = 1:1:N 
    plot(Horizon,r(i,:),'LineWidth',2)
    pub_fig;
    hold on
end
title('Radii change dynamics of all 50 asperities')
xlabel('Time (1000 steps)')
ylabel('Radii (um)')

% figure
% hold on 
% plot(Horizon,h(1,:),'color','b','LineWidth',2)
% pub_fig;
% hold on
% plot(Horizon,r(1,:),'color','r','LineWidth',2)
% title('Height and radii change dynamics of 1 asperity')
% xlabel('Time (1000 steps)')
% ylabel('Radii and Height (um)')
% pub_fig;


%% plots
% 2. Temperature variation
figure 
for i = 1:1:N
    plot(Horizon,T(i,:),'LineWidth',2)
    pub_fig;
    hold on
end
title('Temperature variation of all nodes with time')
xlabel('Time (1000 steps)')
ylabel('Temp (degree C)')


%% plots
% 3. Distance to baseline
figure 
plot(Horizon-dt,st_d_crit,'color','b','LineWidth',2)
title('Distance to baseline variation')
xlabel('Time (1000 steps)')
ylabel('d critical (um)')
pub_fig;

%% plots
% 4. number of active nodes
figure 
plot(Horizon-dt,st_active_nodes,'color','r','LineWidth',2)
title('Active nodes vs time')
xlabel('Time (1000 steps)')
ylabel('# of active nodes')
pub_fig;

%% plots
% 5. The distance between two arbitrary nodes (nodes 1 and 2)
xi_vector = reshape(xi(1,2,:),[length(Horizon),1]);
figure 
plot(Horizon,xi_vector,'color','k','LineWidth',2)
title('The distance between two arbitrary nodes (nodes 1 and 2)')
xlabel('Time (1000 steps)')
ylabel('Distance between nodes 1 and 2 (um)')
pub_fig;


%% Graph plotting and calculation 
% for i = 1:1:50
%     for j = 1:1:50
%         
% center_dist = x_pos_new(i) - x_pos_new(j)  - (radii(i) + radii(j))
% edge_prob = ((center_dist ^ (n-1)) * e^(-center_dist / 2) )/ factorial(n-1)







