%% Model Parameters Fitting with Shilan Jin's data - June 4th 2021

% Consider a 0.25mm x 0.25mm surface for the purpose of modelling.
% Surface packing density is assumed to lie between 0.7 and 0.9 based on
% the specified minimun and maximum radii value of asperities.

% Placing asperities on a 2D space
grid_length = 250;  % Units in micrometers
[Locations, initial_asperity_radii] = random_circle_packing_rectangle([grid_length grid_length],3.65,26,true);
radii_m0 = initial_asperity_radii * sind(1);
x_pos = Locations(:,1);
y_pos = Locations(:,2);

figure;
DT = delaunayTriangulation(x_pos, y_pos);
triplot(DT);
title('Surface Asperities - Network Formation');
xlabel('X (10^{-6})m')
ylabel('Y (10^{-6})m')
pub_fig;

N = size(Locations,1);  % number of asperities
pd = makedist('Weibull',39.3, 4.27);
heights_m0 = random(pd, N, 1);       % initial height distribution - weibull 

asperity_area = pi * sum(initial_asperity_radii.^2);  % units um^2
packing_density = asperity_area / (grid_length^2);
Temp = 20*ones(N,1);  % baseline temperature

params = cell(1,2); 
E = 0.2;
dd = 0.005;
params{1} = E;
params{2} = dd;


%% Stage 0 - Data and Model Comparison

Table0 = readtable('matrix_stage0.csv');
data_stage0 = table2array(Table0);
data_stage0 = reshape(data_stage0, [3264 1]);
data0 = mean(data_stage0) - data_stage0;
count = 0;

% Stage 0 Data Statistics
max_stage0 = max(data0);
mean_stage0 = mean(data0);
stdev_stage0 = std(data0);
min_stage0 = min(data0);
Hurst_stage0 = Gen_hurst(data0);
Sa_stage0 = 0;
for i = 1: 3264
    Sa_stage0 = Sa_stage0 + ((1/3264)*(abs(data0(i) - mean_stage0)));
end
P2P_stage0 = (sum(maxk(data_stage0,320,1),'all') - sum(mink(data_stage0,320,1), 'all'))/320;

% Model 0 Statistics
max_model_0 = max(heights_m0);
min_model_0 = min(heights_m0);
active_nodes = 0;
[Model_H0, mean_model_0, stdev_model_0, Sa_model_0, Hurst_model_0, KS_test_0, p_value_0] = surface_roughness(radii_m0, initial_asperity_radii, heights_m0, N, data_stage0, packing_density);
P2P_model_0 = (sum(maxk(heights_m0,20,1),'all') - sum(mink(heights_m0,20,1), 'all'))/20;

while (Sa_model_0 > 9.3 || stdev_model_0 > 11.3 || p_value_0 < 0.05)
      
     heights_m0 = heights_m0(randperm(length(heights_m0)));
     [Model_H0, mean_model_0, stdev_model_0, Sa_model_0, Hurst_model_0, KS_test_0, p_value_0] = surface_roughness(radii_m0, initial_asperity_radii, heights_m0, N, data_stage0, packing_density);
     count = count + 1;
     if (count > 1000)
         pd = makedist('Weibull',39.3, 4.27);
         heights_m0 = random(pd, N, 1);
         count = 0;
     end     
     [Model_H0, mean_model_0, stdev_model_0, Sa_model_0, Hurst_model_0, KS_test_0, p_value_0] = surface_roughness(radii_m0, initial_asperity_radii, heights_m0, N, data_stage0, packing_density);
end
    
figure
subplot(2,3,1)
histogram(data_stage0, 'Normalization', 'probability', 'BinWidth', 1);
pub_fig;
ylim([0 0.06]);
xlim([0 50]);
title('Histogram of Stage 0 Data');
hold on
plot([0:0.5:50], wblpdf([0:0.5:50], 27.4283, 2.6496), 'r-');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,2)
[Values_s, edges] = histcounts(data_stage0, linspace(0, 50, 51), 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values_s, centers, 'r-', 'LineWidth', 3)
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
title('BAC - Stage 0 Data')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
set(gca,'ydir','reverse');

subplot(2,3,4)
H = histogram(max_model_0 - Model_H0, 'Normalization', 'probability', 'BinWidth', 1);
title('Histogram of Model 0 Sim');
hold on
plot([0:0.5:50], wblpdf([0:0.5:50], 27.4283, 2.6496), 'r-');
pub_fig;
ylim([0 0.06]);
xlim([0 50]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,5)
[Values_m, edges] = histcounts(max_model_0 - Model_H0, linspace(0, 50, 51), 'Normalization', 'cdf');
centers = (edges(1:end-1)+ edges(2:end))/2;
plot(Values_m, centers, 'r-', 'LineWidth', 3);
title('BAC - Model 0 Sim');
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
set(gca,'ydir','reverse');

for i = 2:1:length(Values_s)
    Values_s(i) = Values_s(i) - Values_s(i-1);
    Values_m(i) = Values_m(i) - Values_m(i-1);
end
KL_div_test_stage0 = KLDiv(Values_s, Values_m);


subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min'; 'Mean P2P'; '(KS & KL)'};
Stage_0 = [mean_stage0; stdev_stage0; Sa_stage0; max_stage0; min_stage0; P2P_stage0; p_value_0];
Model_0 = [mean_model_0; stdev_model_0; Sa_model_0; max_model_0; min_model_0; P2P_model_0; KL_div_test_stage0];
T = table(Stage_0, Model_0, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
qqplot(max_model_0 - Model_H0, data_stage0)
pub_fig;
title("Q-Q plot")
ylim([0 50]);
xlim([0 50]);
xlabel("Model Quantiles")
ylabel("Stage 0 - Data Quantiles")


%% Stage 0 to Stage 1 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(1) = 44.48; % total load 
alpha(1) = 0.25; 
kappa_1(1) = 13.75;
kappa_2(1) = 2.85;
speed(1) = 0.53;
sigma(1) = 0.00085;
MRR(1) = 0;

Time = 300; 
k = 2; dt = 0.2;
a_0 = 2.5;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(1);
h = zeros(N,length(Horizon));  h(:,1) = heights_m0;
r = zeros(N,length(Horizon));  r(:,1) = radii_m0;
F = zeros(N,length(Horizon));                   % Force carried by asperities
Pressure = zeros(N, length(Horizon));           % Pressure carried by asperities
R = zeros(N,1); 
diff_heights = zeros(N,1);

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(1),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(h(:,k-1) > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    % Pressure(:,k-1) = F(:,k-1)./((r(:,k-1).^2));
    
    % Temp dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(1)*(T(:,k-1)- Temp) + kappa_1(1)*F(:, k-1) + kappa_2(1)*speed(1)); 
    
    % Sigma dynamics
    Indicator = (T(:,k-1) > (Temp));
    if (k==2)
       s(:,k) = s(:,k-1) + (dt.*s(:,k-1).*Indicator.*T(:,k-1)*(0.1)./Temp);
    else
       s(:,k) = s(:,k-1) + (dt.*s(:,k-1).*Indicator.*(T(:,k-1) - T(:,k-2))./Temp); 
    end
    
    % Differential height dynamics
    diff_heights(:,1) = (dt.*s(:,k-1).*T(:,k-1).*F(:,k-1));
    h(:,k) = h(:,k-1) - diff_heights;    
    
    % Radii update and MRR computation
    R(:,1) = h(:,k-1)./(4*r(:,k-1));
    MR_coeff = exp(-(h(:,k-1)/max(heights_m0).^2)).*exp(-(a_0./r(:,k-1)).^0.0833);
    r(:,k) = r(:,k-1) + (MR_coeff.*R(:,1).*(diff_heights));
    MRR(1) = MRR(1) + sum(pi.*(diff_heights.^2).*h(:,k-1).*(1 - MR_coeff)/4);
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m1 = h(:,length(Horizon));
radii_m1 = r(:,length(Horizon));
MRR(1) = MRR(1) / (250*250*5);

% height, sigma and Temp change plots
figure
subplot(1,3,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of active asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

subplot(1,3,2)
plot(Horizon,s(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Sigma dynamics of asperities')
xlabel('Time (sec)')
ylabel('Sigma')

subplot(1,3,3) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 1')
xlabel('Time (sec)')
ylabel('Temp (degree C)')

%% Stage 1 - Data and Model Comparison

Table1 = readtable('matrix_stage1.csv');
data_stage1 = table2array(Table1);
data_p2p_stage1 = reshape(data_stage1, [102 32]);
data_stage1 = reshape(data_stage1, [3264 1]);
data1 = mean(data_stage1) - data_stage1;

% Stage 1 Data Statistics
max_stage1 = max(data1);
mean_stage1 = mean(data1);
stdev_stage1 = std(data1);
min_stage1 = min(data1);
Hurst_stage1 = Gen_hurst(data1);
Sa_stage1 = 0;
for i = 1: 3264
    Sa_stage1 = Sa_stage1 + ((1/3264)*(abs(data_stage1(i) - mean_stage1)));
end
P2P_stage1 = (sum(maxk(data_stage1,320,1),'all') - sum(mink(data_stage1,320,1), 'all'))/320;

% Model 1 Statistics
max_model_1 = max(heights_m1);
min_model_1 = min(heights_m1);
[Model_H1, mean_model_1, stdev_model_1, Sa_model_1, Hurst_model_1, KS_test_1, p_value_1] = surface_roughness(radii_m1, initial_asperity_radii, heights_m1, N, data_stage1, packing_density);
P2P_model_1 = (sum(maxk(heights_m1,20,1),'all') - sum(mink(heights_m1,20,1), 'all'))/20;

vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);
Fiedler = graph_evolution(x_pos, y_pos, packing_density, Force(1), radii_m1, heights_m1, heights_m0, params, vectorlength, 1);

figure
subplot(2,3,1)
histogram(data_stage1, 'Normalization', 'probability', 'BinWidth', 0.5);
title('Histogram of Stage 1 Data');
pub_fig;
ylim([0 0.4]);
xlim([0 20]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,2)
[Values_s, edges] = histcounts(data_stage1, linspace(0, 20, 30), 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values_s, centers, 'r-', 'LineWidth', 3)
title('BAC - Stage 1 Data')
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_s(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_1 - Model_H1, 'Normalization', 'probability', 'BinWidth', 0.5);
title('Histogram of Model 1 Sim');
pub_fig;
ylim([0 0.4]);
xlim([0 20]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,5)
norm_heights_m1 = max_model_1 - Model_H1;
norm_heights_m1 = norm_heights_m1(norm_heights_m1 < 21);
[Values_m, edges] = histcounts(norm_heights_m1, linspace(0, 20, 30), 'Normalization', 'cdf');
centers = (edges(1:end-1)+ edges(2:end))/2;
plot(Values_m, centers, 'r-', 'LineWidth', 3);
title('BAC - Model 1 Sim');
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_m(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

for i = 2:1:length(Values_s)
    Values_s(i) = Values_s(i) - Values_s(i-1);
    Values_m(i) = Values_m(i) - Values_m(i-1);
end
KL_div_test_stage1 = KLDiv(Values_s, Values_m);

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min';'Mean P2P'; '(KS & KL)'};
Stage_1 = [mean_stage1; stdev_stage1; Sa_stage1; max_stage1; min_stage1; P2P_stage1; p_value_1];
Model_1 = [mean_model_1; stdev_model_1; Sa_model_1; max_model_1; min_model_1; P2P_model_1; KL_div_test_stage1];
T = table(Stage_1, Model_1, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'; 'λ2'; 'MRR (um/min)'};
Values_1 = [Force(1); alpha(1); kappa_1(1); kappa_2(1); sigma(1); Fiedler(1); MRR(1)];
T = table(Values_1, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 1');
   

%% Stage 1 to Stage 2 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(2) = 44.48; % total load 
alpha(2) = 0.22; 
kappa_1(2) = 12.25;
kappa_2(2) = 2.85;
speed(2) = 0.53;
sigma(2) = 0.0011; 
MRR(2) = 0;

Time = 300; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(2);
h = zeros(N,length(Horizon));  h(:,1) = heights_m1;
r = zeros(N,length(Horizon));  r(:,1) = radii_m1;
F = zeros(N,length(Horizon));  % Force carried by asperities
R = zeros(N,1); 
diff_heights = zeros(N,1);

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(2),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(heights_m0 > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % Temp dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(2)*(T(:,k-1)- Temp) + kappa_1(2)*F(:, k-1) + kappa_2(2)*speed(2)); 
    
    % Sigma dynamics
    Indicator = (T(:,k-1) > (Temp));
    if (k==2)
       s(:,k) = s(:,k-1) + (dt.*s(:,k-1).*Indicator.*T(:,k-1)*(0.1)./Temp);
    else
       s(:,k) = s(:,k-1) + (dt.*s(:,k-1).*Indicator.*(T(:,k-1) - T(:,k-2))./Temp); 
    end
    
    % Differential height dynamics
    diff_heights(:,1) = (dt.*s(:,k-1).*T(:,k-1).*F(:,k-1));
    h(:,k) = h(:,k-1) - diff_heights;    
    
    % Radii update and MRR computation
    R(:,1) = h(:,k-1)./(4*r(:,k-1));
    MR_coeff = exp(-(h(:,k-1)/max(heights_m0).^2)).*exp(-(a_0./r(:,k-1)).^0.0833);
    r(:,k) = r(:,k-1) + (MR_coeff.*R(:,1).*(diff_heights));
    MRR(2) = MRR(2) + sum(pi.*(diff_heights.^2).*h(:,k-1).*(1 - MR_coeff)/4);
     
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m2 = h(:,length(Horizon));
radii_m2 = r(:,length(Horizon));
MRR(2) = MRR(2) / (250*250*5);

% height, sigma and Temp change plots
figure
subplot(1,3,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of active asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

subplot(1,3,2)
plot(Horizon,s(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Sigma dynamics of asperities')
xlabel('Time (sec)')
ylabel('Sigma')

subplot(1,3,3) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 2')
xlabel('Time (sec)')
ylabel('Temp (degree C)')


%% Stage 2 - Data and Model Comparison

Table2 = readtable('matrix_stage2.csv');
data_stage2 = table2array(Table2);
data_p2p_stage2 = reshape(data_stage2, [102 32]);
data_stage2 = reshape(data_stage2, [3264 1]);
data2 = mean(data_stage2) - data_stage2;

% Stage 2 Data Statistics
max_stage2 = max(data2);
mean_stage2 = mean(data2);
stdev_stage2 = std(data2);
min_stage2 = min(data2);
Hurst_stage2 = Gen_hurst(data2);
Sa_stage2 = 0;
for i = 1: 3264
    Sa_stage2 = Sa_stage2 + ((1/3264)*(abs(data_stage2(i) - mean_stage2)));
end
P2P_stage2 = (sum(maxk(data_stage2,320,1),'all') - sum(mink(data_stage2,320,1), 'all'))/320;

% Model 2 Statistics
max_model_2 = max(heights_m2);
min_model_2 = min(heights_m2);
[Model_H2, mean_model_2, stdev_model_2, Sa_model_2, Hurst_model_2, KS_test_2, p_value_2] = surface_roughness(radii_m2, initial_asperity_radii, heights_m2, N, data_stage2, packing_density);
P2P_model_2 = (sum(maxk(heights_m2,20,1),'all') - sum(mink(heights_m2,20,1), 'all'))/20;

vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);
Fiedler(2) = graph_evolution(x_pos, y_pos, packing_density, Force(2), radii_m2, heights_m2, heights_m0, params, vectorlength, 2);

figure
subplot(2,3,1)
histogram(data_stage2, 'Normalization', 'probability', 'BinWidth', 0.5);
title('Histogram of Stage 2 Data');
pub_fig;
ylim([0 0.6]);
xlim([0 20]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,2)
[Values_s, edges] = histcounts(data_stage2, linspace(0, 20, 40), 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values_s, centers, 'r-', 'LineWidth', 3)
title('BAC - Stage 2 Data')
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_s(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_2 - Model_H2, 'Normalization', 'probability', 'BinWidth', 0.5);
title('Histogram of Model 2 Sim');
pub_fig;
ylim([0 0.6]);
xlim([0 20]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,5)
norm_heights_m2 = max_model_2 - Model_H2;
norm_heights_m2 = norm_heights_m2(norm_heights_m2 < 20);
[Values_m, edges] = histcounts(norm_heights_m2, linspace(0, 20, 40), 'Normalization', 'cdf');
centers = (edges(1:end-1)+ edges(2:end))/2;
plot(Values_m, centers, 'r-', 'LineWidth', 3);
title('BAC - Model 2 Sim');
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_m(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

for i = 2:1:length(Values_s)
    Values_s(i) = Values_s(i) - Values_s(i-1);
    Values_m(i) = Values_m(i) - Values_m(i-1);
end
KL_div_test_stage2 = KLDiv(Values_s, Values_m);

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min';'Mean P2P'; '(KS & KL)'};
Stage_2 = [mean_stage2; stdev_stage2; Sa_stage2; max_stage2; min_stage2; P2P_stage2; p_value_2];
Model_2 = [mean_model_2; stdev_model_2; Sa_model_2; max_model_2; min_model_2; P2P_model_2; KL_div_test_stage2];
T = table(Stage_2, Model_2, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'; 'λ2'; 'MRR (um/min)'};
Values_1 = [Force(2); alpha(2); kappa_1(2); kappa_2(2); sigma(2); Fiedler(2); MRR(2)];
T = table(Values_1, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 2');


%% Stage 2 to Stage 3 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(3) = 44.48; % total load 
alpha(3) = 0.1; 
kappa_1(3) = 6.75;
kappa_2(3) = 1.5;
speed(3) = 0.53;
sigma(3) = 0.00165; 

Time = 600; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(3);
h = zeros(N,length(Horizon));  h(:,1) = heights_m2;
r = zeros(N,length(Horizon));  r(:,1) = radii_m2;
F = zeros(N,length(Horizon));  % Force carried by asperities
R = zeros(N,1);

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(3),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(heights_m0 > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % Temp dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(3)*(T(:,k-1)- Temp) + kappa_1(3)*F(:, k-1) + kappa_2(3)*speed(3)); 
    
    % Sigma dynamics
    Indicator = (T(:,k-1) > (Temp));
    if (k==2)
       s(:,k) = s(:,k-1) + (dt.*s(:,k-1).*Indicator.*T(:,k-1)*(0.1)./Temp);
    else
       s(:,k) = s(:,k-1) + (dt.*s(:,k-1).*Indicator.*(T(:,k-1) - T(:,k-2))./Temp); 
    end
    
    % Differential height dynamics
    diff_heights(:,1) = (dt.*s(:,k-1).*T(:,k-1).*F(:,k-1));
    h(:,k) = h(:,k-1) - diff_heights;    
    
    % Radii update and MRR computation
    R(:,1) = h(:,k-1)./(4*r(:,k-1));
    MR_coeff = exp(-(h(:,k-1)/max(heights_m0).^2)).*exp(-((r(:,k-1)/a_0).^-0.16));
    r(:,k) = r(:,k-1) + (MR_coeff.*R(:,1).*(diff_heights));
    MRR(1) = MRR(1) + sum(pi.*(diff_heights.^2).*h(:,k-1).*(1 - MR_coeff)/4);
  
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end


heights_m3 = h(:,length(Horizon));
radii_m3 = r(:,length(Horizon));

% height, sigma and Temp change plots
figure
subplot(1,3,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

subplot(1,3,2)
plot(Horizon,s(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Sigma dynamics of asperities')
xlabel('Time (sec)')
ylabel('Sigma')

subplot(1,3,3) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 3')
xlabel('Time (sec)')
ylabel('Temp (degree C)')


%% Stage 3 - Data and Model Comparison

Table3 = readtable('matrix_stage3.csv');
data_stage3 = table2array(Table3);
data_p2p_stage3 = reshape(data_stage3, [102 32]);
data_stage3 = reshape(data_stage3, [3264 1]);
data3 = mean(data_stage3) - data_stage3;

% Stage 3 Data Statistics
max_stage3 = max(data3);
mean_stage3 = mean(data3);
stdev_stage3 = std(data3);
min_stage3 = min(data3);
Hurst_stage3 = Gen_hurst(data3);
Sa_stage3 = 0;
for i = 1: 3264
    Sa_stage3 = Sa_stage3 + ((1/3264)*(abs(data_stage3(i) - mean_stage3)));
end
P2P_stage3 = (sum(maxk(data_stage3,320,1),'all') - sum(mink(data_stage3,320,1), 'all'))/320;

% Model 3 Statistics
max_model_3 = max(heights_m3);
min_model_3 = min(heights_m3);
[Model_H3, mean_model_3, stdev_model_3, Sa_model_3, Hurst_model_3, KS_test_3, p_value_3] = surface_roughness(radii_m3, initial_asperity_radii, heights_m3, N, data_stage3, packing_density);
P2P_model_3 = (sum(maxk(heights_m3,20,1),'all') - sum(mink(heights_m3,20,1), 'all'))/20;

vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);
Fiedler(3) = graph_evolution(x_pos, y_pos, packing_density, Force(3), radii_m3, heights_m3, heights_m0, params, vectorlength, 3);

figure
subplot(2,3,1)
histogram(data_stage3, 'Normalization', 'probability', 'BinWidth', 0.2);
title('Histogram of Stage 3 Data');
pub_fig;
ylim([0 0.8]);
xlim([0 10]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,2)
[Values_s, edges] = histcounts(data_stage3, linspace(0, 10, 20), 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values_s, centers, 'r-', 'LineWidth', 3)
title('BAC - Stage 3 Data')
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_s(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_3 - heights_m3, 'Normalization', 'probability', 'BinWidth', 0.2);
title('Histogram of Model 3 Sim');
pub_fig;
ylim([0 0.8]);
xlim([0 10]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,5)
norm_heights_m3 = max_model_3 - heights_m3;
norm_heights_m3 = norm_heights_m3(norm_heights_m3 < 10);
[Values_m, edges] = histcounts(norm_heights_m3, linspace(0, 10, 20), 'Normalization', 'cdf');
centers = (edges(1:end-1)+ edges(2:end))/2;
plot(Values_m, centers, 'r-', 'LineWidth', 3);
title('BAC - Model 3 Sim');
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_m(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

for i = 2:1:length(Values_s)
    Values_s(i) = Values_s(i) - Values_s(i-1);
    Values_m(i) = Values_m(i) - Values_m(i-1);
end
KL_div_test_stage3 = KLDiv(Values_s, Values_m);

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min';'Mean P2P'; '(KS & KL)'};
Stage_3 = [mean_stage3; stdev_stage3; Sa_stage3; max_stage3; min_stage3; P2P_stage3; p_value_3];
Model_3 = [mean_model_3; stdev_model_3; Sa_model_3; max_model_3; min_model_3; P2P_model_3; KL_div_test_stage3];
T = table(Stage_3, Model_3, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'; 'λ2'};
Values_1 = [Force(3); alpha(3); kappa_1(3); kappa_2(3); sigma(3); Fiedler(3)];
T = table(Values_1, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 3');



%% Stage 3 to Stage 4 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(end) = 44.48; % total load 
alpha(end) = 0.075; 
kappa_1(end) = 3.5;
kappa_2(end) = 1.2;
speed(end) = 0.53;
sigma(end) = 0.0017; 

Time = 600; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(end);
h = zeros(N,length(Horizon));  h(:,1) = heights_m3;
r = zeros(N,length(Horizon));  r(:,1) = radii_m3;
F = zeros(N,length(Horizon));  % Force carried by asperities
R = zeros(N,1);

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m3);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(end),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(h(:,k-1) > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(end)*(T(:,k-1)- Temp) + kappa_1(end)*F(:, k-1) + kappa_2(end)*speed(end));
         
    if (k==2)
        s(:,k) = s(:,k-1) + (dt.*s(:,k-1)*T(:,k-1)*(0.1)./Temp);
    else
        s(i,k) = s(:,k-1) + (dt*s(:,k-1).*(T(:,k-1) - T(:,k-2))./Temp);
    end
    
    R(:,1) = h(:,k-1)./(4*r(:,k-1));
    diff_height = dt.*s(active_nodes,k-1).*T(active_nodes,k-1).*F(active_nodes,k-1);
    h(:,k) = h(:,k-1);
    h(active_nodes,k) = h(active_nodes, k-1) + min(diff_height);
    r(:,k) = r(:,k-1) + (dt.*exp((-h(:,k-1).^2)./4000).*R(:,1)*s(i,k-1)*T(i,k-1)*F(i,k-1));
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m4 = h(:,length(Horizon));
radii_m4 = r(:,length(Horizon));

% height, sigma and Temp change plots
figure
subplot(1,3,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

subplot(1,3,2)
plot(Horizon,s(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Sigma dynamics of asperities')
xlabel('Time (sec)')
ylabel('Sigma')

subplot(1,3,3) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 4')
xlabel('Time (sec)')
ylabel('Temp (degree C)')


%% Stage 4 - Data and Model Comparison

Table4 = readtable('matrix_stage4.csv');
data_stage4 = table2array(Table4);
data_p2p_stage4 = reshape(data_stage4, [102 32]);
data_stage4 = reshape(data_stage4, [3264 1]);
data4 = mean(data_stage4) - data_stage4;

% Stage 4 Data Statistics
max_stage4 = max(data4);
mean_stage4 = mean(data4);
stdev_stage4 = std(data4);
min_stage4 = min(data4);
Hurst_stage4 = Gen_hurst(data4);
Sa_stage4 = 0;
for i = 1: 3264
    Sa_stage4 = Sa_stage4 + ((1/3264)*(abs(data_stage4(i) - mean_stage4)));
end
P2P_stage4 = (sum(maxk(data_stage4,320,1),'all') - sum(mink(data_stage4,320,1), 'all'))/320;

% Model 4 Statistics
max_model_4 = max(heights_m4);
mean_model_4 = mean((heights_m4.*(radii_m4.^2))./sum(radii_m4.^2));
stdev_model_4 = std((heights_m4.*(radii_m4.^2))./sum(radii_m4.^2));
min_model_4 = min(heights_m4);
Hurst_model_4 = Gen_hurst((heights_m4.*(radii_m4.^2))./sum(radii_m4.^2));
Sa_model_4 = abs(((heights_m4.*(radii_m4.^2)) - mean_model_4)./sum(radii_m4.^2));

[KS_test_4, p_value_4] = KSDivtest(data_stage4, max_model_4 - heights_m4);
P2P_model_4 = (sum(maxk(heights_m4,20,1),'all') - sum(mink(heights_m4,20,1), 'all'))/20;

vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);
Fiedler(4) = graph_evolution(x_pos, y_pos, packing_density, Force(4), r(:,length(Horizon)), h(:,length(Horizon)), heights_m0, params, vectorlength, 4);

figure
subplot(2,3,1)
histogram(data_stage4, 'Normalization', 'probability', 'BinWidth', 0.05);
title('Histogram of Stage 4 Data');
pub_fig;
ylim([0 0.8]);
xlim([0 4]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,2)
[Values_s, edges] = histcounts(data_stage4, linspace(0, 4, 32), 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values_s, centers, 'r-', 'LineWidth', 3)
title('BAC - Stage 4 Data')
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_s(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_4 - heights_m4, 'Normalization', 'probability', 'BinWidth', 0.05);
title('Histogram of Model 4 Sim');
pub_fig;
ylim([0 0.8]);
xlim([0 4]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,5)
norm_heights_m4 = max_model_4 - heights_m4;
norm_heights_m4 = norm_heights_m4(norm_heights_m4 < 4);
[Values_m, edges] = histcounts(norm_heights_m4, linspace(0, 4, 32), 'Normalization', 'cdf');
centers = (edges(1:end-1)+ edges(2:end))/2;
plot(Values_m, centers, 'r-', 'LineWidth', 3);
title('BAC - Model 4 Sim');
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_m(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

for i = 2:1:length(Values_s)
    Values_s(i) = Values_s(i) - Values_s(i-1);
    Values_m(i) = Values_m(i) - Values_m(i-1);
end
KL_div_test_stage4 = KLDiv(Values_s, Values_m);

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min';'Mean P2P'; '(KS & KL)'};
Stage_4 = [mean_stage4; stdev_stage4; Sa_stage4; max_stage4; min_stage4; P2P_stage4; p_value_4];
Model_4 = [mean_model_4; stdev_model_4; Sa_model_4; max_model_4; min_model_4; P2P_model_4; KL_div_test_stage4];
T = table(Stage_4, Model_4, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'; 'λ2'};
Values_1 = [Force(4); alpha(4); kappa_1(4); kappa_2(4); sigma(4); Fiedler(4)];
T = table(Values_1, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 4');



%% Stage 4 to Stage 5 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(5) = 44.48; % total load 
alpha(5) = 0.065; 
kappa_1(5) = 6;
kappa_2(5) = 1.5;
speed(5) = 0.53;
sigma(5) = 0.0018; 

Time = 600; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(5);
h = zeros(N,length(Horizon));  h(:,1) = heights_m4;
r = zeros(N,length(Horizon));  r(:,1) = radii_m4;
F = zeros(N,length(Horizon));  % Force carried by asperities
R = zeros(N,1);

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m4);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(5),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(h(:,k-1) > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(5)*(T(:,k-1)- Temp) + kappa_1(5)*F(:, k-1) + kappa_2(5)*speed(5));
    
    for i = 1:1:N
         Indicator = (T(i,k-1) > (Temp));
         if (k==2)
            s(i,k) = s(i,k-1) + (dt*s(i,k-1)*Indicator(i)*T(i,k-1)*0.1/Temp(i));
         else
            s(i,k) = s(i,k-1) + (dt*s(i,k-1)*Indicator(i)*(T(i,k-1) - T(i,k-2))/Temp(i)); 
         end
         
            R(i,1) = h(i,k-1)/(4*r(i,k-1));
            h(i,k) = h(i,k-1) - (dt*s(i,k-1)*T(i,k-1)*F(i,k-1));
            r(i,k) = r(i,k-1) + (dt*exp(-h(i,k-1)^2/4000)*R(i,1)*s(i,k-1)*T(i,k-1)*F(i,k-1));
       
    end
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m5 = h(:,length(Horizon));
radii_m5 = r(:,length(Horizon));

% height, sigma and Temp change plots
figure
subplot(1,3,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

subplot(1,3,2)
plot(Horizon,s(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Sigma dynamics of asperities')
xlabel('Time (sec)')
ylabel('Sigma')

subplot(1,3,3) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 5')
xlabel('Time (sec)')
ylabel('Temp (degree C)')


%% Stage 5 - Data and Model Comparison

Table5 = readtable('matrix_stage5.csv');
data_stage5 = table2array(Table5);
data_p2p_stage5 = reshape(data_stage5, [102 32]);
data_stage5 = reshape(data_stage5, [3264 1]);
data5 = mean(data_stage5) - data_stage5;

% Stage 5 Data Statistics
max_stage5 = max(data5);
mean_stage5 = mean(data5);
stdev_stage5 = std(data5);
min_stage5 = min(data5);
Hurst_stage5 = Gen_hurst(data5);
Sa_stage5 = 0;
for i = 1: 3264
    Sa_stage5 = Sa_stage5 + ((1/3264)*(abs(data_stage5(i) - mean_stage5)));
end
P2P_stage5 = (sum(maxk(data_stage5,320,1),'all') - sum(mink(data_stage5,320,1), 'all'))/320;

% Model 5 Statistics
max_model_5 = max(heights_m5);
mean_model_5 = mean(heights_m5);
stdev_model_5 = std(heights_m5);
min_model_5 = min(heights_m5);
Hurst_model_5 = Gen_hurst(heights_m5);
Sa_model_5 = 0;
for i = 1: N
    Sa_model_5 = Sa_model_5 + ((1/(N))*(abs(heights_m5(i) - mean_model_5)));
end
[KS_test_5, p_value_5] = KSDivtest(data_stage5, max_model_5 - heights_m5);
P2P_model_5 = (sum(maxk(heights_m5,20,1),'all') - sum(mink(heights_m5,20,1), 'all'))/20;

vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);
Fiedler(5) = graph_evolution(x_pos, y_pos, packing_density, Force(5), r(:,length(Horizon)), h(:,length(Horizon)), heights_m0, params, vectorlength, 5);

figure
subplot(2,3,1)
histogram(data_stage5, 'Normalization', 'probability', 'BinWidth', 0.1);
title('Histogram of Stage 5 Data');
pub_fig;
ylim([0 0.8]);
xlim([0 2]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,2)
[Values_s, edges] = histcounts(data_stage5, linspace(0, 2, 20), 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values_s, centers, 'r-', 'LineWidth', 3)
title('BAC - Stage 5 Data')
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_s(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_5 - heights_m5, 'Normalization', 'probability', 'BinWidth', 0.1);
title('Histogram of Model 4 Sim');
pub_fig;
ylim([0 0.8]);
xlim([0 2]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,5)
norm_heights_m5 = max_model_5 - heights_m5;
norm_heights_m5 = norm_heights_m5(norm_heights_m5 < 2);
[Values_m, edges] = histcounts(norm_heights_m5, linspace(0, 2, 20), 'Normalization', 'cdf');
centers = (edges(1:end-1)+ edges(2:end))/2;
plot(Values_m, centers, 'r-', 'LineWidth', 3);
title('BAC - Model 5 Sim');
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_m(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

for i = 2:1:length(Values_s)
    Values_s(i) = Values_s(i) - Values_s(i-1);
    Values_m(i) = Values_m(i) - Values_m(i-1);
end
KL_div_test_stage5 = KLDiv(Values_s, Values_m);

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min';'Mean P2P'; '(KS & KL)'};
Stage_5 = [mean_stage5; stdev_stage5; Sa_stage5; max_stage5; min_stage5; P2P_stage5; p_value_5];
Model_5 = [mean_model_5; stdev_model_5; Sa_model_5; max_model_5; min_model_5; P2P_model_5; KL_div_test_stage5];
T = table(Stage_5, Model_5, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'; 'λ2'};
Values_1 = [Force(5); alpha(5); kappa_1(5); kappa_2(5); sigma(5); Fiedler(5)];
T = table(Values_1, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 5');



%% Parameter Plotting

figure
subplot(2,3,1)
stages = 1:1:3;
plot(stages, sigma(stages),'b--o', 'Linewidth', 1.5)
title('Sigma vs stage')
pub_fig;
ylabel('Sigma')
xlabel('Stage number')
hold on
fit(stages',sigma(stages)','spline');
xticks([1 2 3]);
ylim([0 0.002]);

subplot(2,3,2)
stages = 1:1:3;
plot(stages, alpha(stages),'r--o', 'Linewidth', 1.5)
title('Alpha vs stage')
pub_fig;
ylabel('alpha')
xlabel('Stage number')
hold on
fit(stages',alpha(stages)','spline');
xticks([1 2 3]);
ylim([0 0.2]);

subplot(2,3,3)
stages = 1:1:3;
plot(stages, kappa_1(stages),'r--o', 'Linewidth', 1.5)
title('kappa_1 (Force) vs stage')
pub_fig;
ylabel('kaapa_1')
xlabel('Stage number')
hold on
fit(stages',kappa_1(stages)','spline');
xticks([1 2 3]);
ylim([0 10]);

subplot(2,3,4)
stages = 1:1:3;
plot(stages, Fiedler(stages),'r--o', 'Linewidth', 1.5)
title('Fiedler Number vs stage')
pub_fig;
ylabel('Fiedler number λ2')
xlabel('Stage number')
hold on
fit(stages',Fiedler(stages)','spline');
xticks([1 2 3]);
ylim([10 15]);

subplot(2,3,5)
stages = 0:1:3;
Sa_stages = [Sa_stage0 Sa_stage1 Sa_stage2 Sa_stage3];
Sa_models = [Sa_model_0 Sa_model_1 Sa_model_2 Sa_model_3];
plot(stages, Sa_stages,'black--', 'Linewidth', 1.5)
title('Camparison of Sa values')
pub_fig;
ylabel('Sa (um)')
xlabel('Stage number')
hold on
plot(stages, Sa_models,'r--o', 'Linewidth', 1.5)
legend('Data', 'Model');
xticks([0 1 2 3]);
ylim([0 10]);

subplot(2,3,6)
stages = 0:1:3;
stdev_stages = [stdev_stage0 stdev_stage1 stdev_stage2 stdev_stage3];
stdev_models = [stdev_model_0 stdev_model_1 stdev_model_2 stdev_model_3];
plot(stages, stdev_stages,'black--', 'Linewidth', 1.5)
title('Camparison of Std dev.')
pub_fig;
ylabel('Std dev (um)')
xlabel('Stage number')
hold on
plot(stages, stdev_models,'r--o', 'Linewidth', 1.5)
legend('Data', 'Model');
xticks([0 1 2 3]);
ylim([0 10]);


%%
% figure
% qqplot(max_model_0 - heights_m0, data_stage0, 'r-')
% hold on
% qqplot(max_model_1 - heights_m1, data_stage1)
% title("Stage 1 Comparison")
% pub_fig;
% 
% 
% norm_heights_m1 = max_model_1 - heights_m1;
% norm_heights_m1 = norm_heights_m1(norm_heights_m1 < 22);
% figure
% qqplot(norm_heights_m1, data_stage1)
% pub_fig;
% title("Q-Q plot")
% ylim([0 20]);
% xlim([0 20]);
% xlabel("Model Quantiles")
% ylabel("Stage 1 - Data Quantiles")
