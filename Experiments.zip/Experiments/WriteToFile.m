%% Write to File
fid = fopen('InitialHeightsVersion1.dat','wt');                                                    
fprintf(fid,'%f \n',retrieveSimHeightsCP);                                             
fclose(fid); 

%%
