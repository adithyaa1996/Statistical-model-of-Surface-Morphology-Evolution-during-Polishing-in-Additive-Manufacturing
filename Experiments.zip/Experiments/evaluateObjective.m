%% Define the objective function for simulated annealing

function f=evaluateObjective(x)
% Retrieve Heights for stage0
% Heights will already be set using setGlobalheights in the mainframe
dataheights=retrieveHeights();
% extract probability fit from stage0 data
pd=fitdist(dataheights(:,1),'Gamma');
% use probability distribution to generate heights for simulation
N=50;
simheights=random(pd,N,1);
% radii = ones(N,1)*0.5 + randn(N,1)*0.05; % initial radii distribution


% initialise parameters for running dynamics
params = cell(1,2); 
% E = 1; dd = 0.01;
E=0.2;dd=0.01;
params{1} = E; params{2} = dd;
% Force = 1;
Force=44.48;
alpha = x(1);kappa_1 = x(2);kappa_2 = x(3);sigma = x(4);
speed = 0.53;
rho = 1;
% initialise evolution parameters
T=zeros(N,2); T(:,1)=25*ones(N,1);T0=T(:,1);
h=zeros(N,2); h(:,1)=simheights;
r=zeros(N,2); r(:,1)=ones(N,1)*0.5 + randn(N,1)*0.05;
% F=zeros(N,1);
% Run dynamics
Time=300; 
dt=0.2;
for t=dt:dt:Time
    d_critical = solve_for_d(Force,r(:,1),h(:,1),params);
    F = zeros(N,1);
    active_nodes = find(simheights>d_critical);
    F(active_nodes) = (2/3)*E*sqrt(r(active_nodes,1)).*(h(active_nodes,1)-d_critical*ones(length(active_nodes),1)).^1.5; % force carried by each node. 
    
    %dynamics
    T(:,2) = T(:,1) + dt*(-alpha*(T(:,1)-T0) + kappa_1*F + kappa_2*speed);
    h(:,2) = h(:,1) + dt*(-sigma*T(:,1).*F);
    r(:,2) = r(:,1) + dt*(rho*sigma*T(:,1).*F);
    
    %update previous time step
    T(:,1)=T(:,2);
    h(:,1)=h(:,2);
    r(:,1)=r(:,2);
end
% call kldiv to evaluate objective
% Now with the dynamics in place, the final height distribution is h(:,2)
pdstage1=fitdist(dataheights(:,2),'Gamma');
pdsimulated=fitdist(h(:,2),'Gamma');
vectorC=0.5:0.5:(max(max(dataheights(:,2)),max(h(:,2)))+5);
pdfstage1=pdf(pdstage1,vectorC); pdfstage1=pdfstage1/sum(pdfstage1);
pdfsimulated=pdf(pdsimulated,vectorC); pdfsimulated=pdfsimulated/sum(pdfsimulated);
f=kldiv(vectorC,pdfstage1,pdfsimulated);
% hstage=dataheights(:,2);
% hsimulated=h(:,2);
% histogram(dataheights(:,2));
% title('Dataheights, Stage1')
% figure;
% histogram(h(:,2));
% title('SimulatedHeights, Stage1');

