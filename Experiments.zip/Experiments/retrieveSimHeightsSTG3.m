function f=retrieveSimHeightsSTG3()
global simheightsSTG3
f=simheightsSTG3;

