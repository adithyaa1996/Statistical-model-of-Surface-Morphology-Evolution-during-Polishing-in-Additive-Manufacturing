function f=retrieveModelHeightsSTG9()
global modelheightsSTG9
f=modelheightsSTG9;