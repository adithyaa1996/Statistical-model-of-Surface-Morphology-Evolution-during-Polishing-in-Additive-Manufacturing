% MValidate3 Stage 2 - Stage 3 polishing

%% Initialise heights,read heights EN 70/ SA 30
setParametersSTG2(); 
%% Initialise heights, read heights EN 80/ SA 20
setParametersSTG1(pkT2);
setParametersSTG2(pkT6);
%% Different values
% 80-20 Evaluation
p16=[3.2733;0.0022;1.6206]; % SA 1.8645 klD 3.9983 obj=3.5715
p16b=[9.5469;0.0006;0.1086]; % SA 4.8179 klD 3.2555 obj=3.5679 * updated
p17=[9.2471;0.0080;2.9214]; % SA 3.3658 klD 3.0898 obj=3.145 ****
p17b=[9.2980;0.0118;2.6507]; % SA 2.2988 klD 3.5079 obj=3.266 *** selection updated
p18=[0.45961903;0.00220408;0.07628310]; % SA 2.2354 klD 3.5395 obj=3.2786 updated
p18b=[8.4370;0.0101;4.6213]; % SA 3.0582 klD 3.5055 obj=3.4160
p19=[9.2124;0.0113;4.6168]; % SA 3.1550 klD 3.1083 obj=3.0584 * SELECT
% -------------------------------
pkT7=[1.616783;0.004649;0.000364]; % SA 3.2372 klD 2.8353
pkT8=[1.372173;0.003548;0.000233]; % SA 3.6287 klD 2.5930 ** OPTIMAL ** || SA 3.6545 klD 2.0136

%% Evaluate
[funcVal,heightsForSACalc]=objectiveSTG2To3(pkT8,1,1);  

%% Ideas for experiment design

% lb=[0.01;0.5;0.1;0.00001];
% ub=[20;40;10;0.04];
% 
% lb=[0;0;0];
% ub=[10;1;10];
lb=[0.025;0.00008;0.00002];
ub=[2.5;0.008;0.002];
ObjectiveFunction = @objectiveSTG2To3;

% [xmin,fxmin]=simulatedAnnealingSolution(p6,ObjectiveFunction,lb,ub);

options = optimoptions(@simulannealbnd,'FunctionTolerance',0.0001,'MaxIterations',3000,'Display','iter');
[p,fval,exitflag,output]=simulannealbnd(ObjectiveFunction,pkT7,lb,ub,options);  

%% Average Objective value
f11=zeros(10,1);klD=zeros(10,1);
for j=1:1:10
    disp(j);
    [f,h]=objectiveSTG2To3(pkT8,1,0);
    f11(j)=f;
    germa66=max(h)-h;
    % perform raid
    germa66(germa66>15)=[];
    germa662=datastage(:,4);
    germa662(germa662>15)=[];
    germa662(germa662<0)=[];
    klD(j)=percentDivergence(germa662,germa66,70,0.1);
end
f11=mean(f11); klD=mean(klD);


%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:1000
    disp(counter);
%     lb=[0;0;0];
%     lb=[0.012;0.00004;0.00001];
%     lb=[4;6;1;0.001];
%     ub=[10;1;10];
%     ub=[5;0.016;0.004];
    lb=[0.025;0.00008;0.00002];
    ub=[2.5;0.008;0.002];
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand(3,1);
    [fh,hh]=objectiveSTG2To3(xrandom,0.2,0.8);
    
    if fh<min_val
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.5;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,4));
hist2.BinWidth=0.5;
hist2.Normalization='probability';
%% Plot
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
color1=[0 0 0];
set(cdf1,'LineWidth',3.5,'LineStyle','-','color',color1); % Sigma Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,4));
% color2=[0.8500, 0.3250, 0.0980];
color2=[0 0 0];
set(cdf2,'LineWidth',3,'LineStyle','--','color',color2); % Data
xlabel('x','FontSize',18);
ylabel('Cumulative Probability','FontSize',18);

% hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Best Fit Parameters
% % hold on;
% lgd=legend('Simulation','Data');
% lgd.FontSize=18;
% % reposition legend
% legend('Location','southeast');
title('')
set(gca,'FontSize',14);
yh=get(gca,'ylabel');
p34=get(yh,'position');
p34(1)=-0.4+p34(1);
set(yh,'position',p34);

% set a text box
annotation('textbox',  [0.5, 0.6, 0.1, 0.1], 'String', 'KLdiv = 2.59   \DeltaSa = 3.62','FontSize',16)
%% Plot2
figure;
germa66=max(heightsForSACalc)-heightsForSACalc;
% perform raid
germa66(germa66>15)=[];
cdf1=cdfplot(germa66);
% color1=[0 0 0];
set(cdf1,'LineWidth',5,'LineStyle','-','color','blue'); % Sigma Best Fit Stage
hold on;
germa662=datastage(:,4);
germa662(germa662>15)=[];
germa662(germa662<0)=[];
cdf2=cdfplot(germa662);
% color2=[0.8500, 0.3250, 0.0980];
% color2=[0 0 0];
set(cdf2,'LineWidth',5,'LineStyle','-','color','red'); % Data
xlabel('Heights (10^-6 m)','FontSize',22,'fontweight','bold');
ylabel('Quantiles','FontSize',22,'fontweight','bold');

% hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Best Fit Parameters
% % hold on;
lgd=legend([cdf2 cdf1],'Data','Model Surface','FontSize',22);
lgd.FontSize=14;
% % reposition legend
legend('Location','southwest','fontweight','bold');
title('Bearing Area Curves - Stage 3','FontSize',24)
% set(gca,'FontSize',18);
set(gca,'View',[90 -90]);
% set(gca,'ydir','reverse')
set(gca,'xdir','reverse')
yh=get(gca,'ylabel');
p34=get(yh,'position');
p34(1)=-0.4+p34(1);
set(yh,'position',p34);
box on
ax=gca;
ax.LineWidth=2;
xticks([0,5,10,15])
yticks([0,0.2,0.4,0.6,0.8,1])
% set a text box
% SA 2.8485 klD 2.0276
annotation('textbox', [0.15, 0.3, 0.1, 0.1], 'String', ['KL Div = 2.0136' newline '\DeltaSa = 3.6545'],'LineWidth',2,'FontSize',16,'fontweight','bold');