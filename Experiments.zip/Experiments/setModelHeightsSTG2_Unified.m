function setModelHeightsSTG2_Unified()
% xsa11=[4.6749;27.0331;8.8197;0.0023];
xta1=[4.7101;23.5887;6.5008;0.0070];
[hh,rr]=returnParametersSTG1To2(xta1);

global modelradiiSTG2
modelradiiSTG2=rr;
% N = size(Locations,1); 
global modelheightsSTG2
modelheightsSTG2=hh;

