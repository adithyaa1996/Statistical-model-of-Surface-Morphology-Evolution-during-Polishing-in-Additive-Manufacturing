function setParametersSTG2(x)
% xsa6=[4.3925;13.0070;1.6878;0.0087];
% [hh,rr]=returnParametersSTG0To1(x);
[hh,rr]=getParamsSTG1To2(x);

global modelradiiSTG2
modelradiiSTG2=rr;
% N = size(Locations,1); 
global modelheightsSTG2
modelheightsSTG2=hh;
