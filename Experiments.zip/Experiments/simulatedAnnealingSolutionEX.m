%% Simulated Annealing for Global Optimization
function [xmin,fxmin]=simulatedAnnealingSolutionEX(x0,objective,lb,ub)
%-----------------------------------------------------------
% Initialisation phase
%-----------------------------------------------------------
x=x0; T0=100; L0=10; 
k=1; K=200;
L=zeros(K+1,1);
T=zeros(K+1,1);
L(1)=L0; T(1)=T0;
% fx=objective(x,1,1);
fx=objective(x,1,1);
r=0.99;
% stepsize=[0.02;0.8;0.2;0.0002]; % change as you need
% stepsize=[0.01;0.5;0.1;0.0001]; % change as you need
% stepsize=[0.1;0.1;0.1;0.000001];
stepsize=0.0001;
% stepsize=stepsize*3;
% stepsize=[0.01;0.01]; for TEST
% tolerance=0.000001; for future dev
f=zeros(K+1,1);
%-----------------------------------------------------------
% While termination condition is not satisfied
%-----------------------------------------------------------
while (k<=K && fx>1)
    % i.e if KLDIV dips below 0.05, exit, we are done for now!
    % or exit if we are done with waiting K steps
    for l=1:L(k)
        [xprime,success]=genNeighbor(x,stepsize,lb,ub);
        if success==0
            disp("Same Neighbor");
        end
        
%         fxprime=objective(xprime,1,1);
        fxprime=objective(xprime,1,1);
        if fxprime<=fx
            x=xprime;
            fx=fxprime;
            f(k)=fx;
            
        else
            if exp((fx-fxprime)/T(k))>rand
                x=xprime;
                fx=fxprime;
                f(k)=fx;
            end
        end
    end
    k=k+1;
    % inert condition to check whether f value is not changing
    if k>7
       l=min(sum(f>0),7);   
       l1=l;
       s=0;
       while(l>=0)
         s=s+f(k-l);
         l=l-1;
       end
       s=s/l1;
       if abs(s-f(k-1))<0.00001
          % we are stuck in a local solution
          xmin=x;
          fxmin=fx;
          return;
       end
    end
    
    
    disp(k);
    disp(fx);
    disp(x);
    % Calculate new Length
    L(k)=L(k-1); % learn and make better
    % Calculate new Temperature   
    T(k)=r*T(k-1);    
end
xmin=x;
fxmin=fx;
%-----------------------------------------------------------