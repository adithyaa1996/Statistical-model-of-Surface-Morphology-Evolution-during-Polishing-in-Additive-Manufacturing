function f=retrieveModelRadiiSTG6()
global modelradiiSTG6;
f=modelradiiSTG6;
