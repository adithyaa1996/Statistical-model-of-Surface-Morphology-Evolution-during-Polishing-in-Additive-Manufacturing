function setParametersSTG7(x)
% xsa6=[4.3925;13.0070;1.6878;0.0087];
% [hh,rr]=returnParametersSTG0To1(x);
[hh,rr]=getParamsSTG6To7(x);

global modelradiiSTG7
modelradiiSTG7=rr;
% N = size(Locations,1); 
global modelheightsSTG7
modelheightsSTG7=hh;
