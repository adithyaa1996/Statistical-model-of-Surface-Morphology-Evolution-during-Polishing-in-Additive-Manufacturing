function setModelRadiiSTG0()
global modelRadiiSTG0
modelRadiiSTG0=load('Initial_asperity_radii_Stage0.mat').initial_asperity_radii;

