%% mainframe
setGlobalHeights();
x0=[0.32;5;0.5;0.00018];% alpha, kappa_1,kappa_2,sigma
ObjectiveFunction=@evaluateObjective;
lb=[0.22;4;0.3;];
ub=[];
[x,fval,exitFlag,output] = simulannealbnd(ObjectiveFunction,x0);
% [fh,hstage,hsimulated]=evaluateObjective(x);
% ObjectiveFunction = @simple_objective;
% x0 = [0.5 0.5];   % Starting point
% rng default % For reproducibility
% [x,fval,exitFlag,output] = simulannealbnd(ObjectiveFunction,x0);