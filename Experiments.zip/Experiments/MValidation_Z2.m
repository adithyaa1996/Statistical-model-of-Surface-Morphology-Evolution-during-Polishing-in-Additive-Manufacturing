%% So where do we start from
% Stage0-stage1
% Step1: Initialise heights, read heights
% Step2: Apply modified dynamics
% Step3: Define the objective for the new height functions
% Step4: Find objective value

%% Initialise heights,read heights EN
setModelHeightsSTG1_parametric([sial1(1);1;1;sial1(2)]); % Executed
%% Initialise heights,read heights SA
setModelHeightsSTG1_parametric([sial2(1);1;1;sial2(2)]);% Executed
%% Initialise heights,read heights SA+EN (10/90)
setModelHeightsSTG1_parametric([sial3(1);1;1;sial3(2)]);% Executed
%% Initialise heights,read heights SA+EN (30/70)
setModelHeightsSTG1_parametric([sial4(1);1;1;sial4(2)]);% Executed

%% Different values
% Solve for Entropy 
sial5=[3.8839;0.0011]; % sa 3.1225 klD 2.0279
% Solve for Del_SA
sial6=[2.0927;0.0151]; % sa 0.0222 klD 3.8975 
sial6b=[7.7507;0.0015]; % sa 0.0162 klD 3.7204
% Solve for convex comb SA and Entropy (10/90)
sial7=[9.7835;0.0012]; % sa klD
sial7b=[2.1550;0.0010]; % sa 2.7863 klD 2.0843
% Solve for convex comb SA and Entropy (30/70)
sial8=[4.5928;0.0059]; % sa 0.9570 klD 2.7326 ***
% Solve for convex comb SA and Entropy (50/50)
sial9=[7.4530;0.0086]; %sa 1.1011 klD 2.7440

%% Evaluate
[funcVal,heightsForSACalc]=evalObjectiveStage1To2V2_Z(sial8,1,1); 

%% Ideas for experiment design

lb=[0.01;0.5;0.1;0.00001];
ub=[20;40;10;0.04];
ObjectiveFunction = @evalObjectiveStage1To2V2_2;

[xmin,fxmin]=simulatedAnnealingSolution(xsa11,ObjectiveFunction,lb,ub);

%% Average Objective value
f11=zeros(20,1);klD=zeros(20,1);
for j=1:1:20
    disp(j);
    [f,h]=evalObjectiveStage1To2V2_Z(sial8,1,0);
    f11(j)=f;
    klD(j)=percentDivergence(datastage(:,3),max(h)-h,70,0.1);
end
f11=mean(f11); klD=mean(klD);

%% Difference in KLDiv
upperlevel=70;intervalWidth=0.1;
kldiv=percentDivergence(datastage(:,2),max(heightsForSACalc)-heightsForSACalc,upperlevel,intervalWidth);
disp(kldiv);
%% Difference in SA values

mean_model = mean(heightsForSACalc);
M = length(heightsForSACalc);
Sa_model = (1/M)*sum(abs(heightsForSACalc - mean_model),1);% use same formula 

mean_data=mean(datastage(:,2));
Sa_data=(1/length(datastage(:,2)))*sum(abs(datastage(:,2)-mean_data),1);
diffSA=abs(Sa_model-Sa_data);
disp(diffSA);
%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:2000
    disp(counter);
    lb=[1;0.00000001];
%     lb=[4;6;1;0.001];
    ub=[10;1];
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand(2,1);
    [fh,hh]=evalObjectiveStage1To2V2_Z(xrandom,0.3,0.7);
    
    if fh<min_val
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.5;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,3));
hist2.BinWidth=0.5;
hist2.Normalization='probability';

%% Graphics module
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
color1=[0 0 0];
set(cdf1,'LineWidth',3.5,'LineStyle','-','color',color1); % Sigma Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,3));
% color2=[0.8500, 0.3250, 0.0980];
color2=[0 0 0];
set(cdf2,'LineWidth',3,'LineStyle','--','color',color2); % Data
xlabel('x','FontSize',18);
ylabel('Cumulative Probability','FontSize',18);

% hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Best Fit Parameters
% hold on;
lgd=legend('Simulation','Data');
lgd.FontSize=18;
legend('Location','southeast');
title('')
set(gca,'FontSize',14);
% yh=get(gca,'ylabel');
% p34=get(yh,'position');
% p34(1)=p34(1);
% set(yh,'position',p34);

% set a text box
annotation('textbox', [0.5, 0.6, 0.1, 0.1], 'String', 'KLdiv = 2.73    \DeltaSa = 0.96','FontSize',16)
% %% Plot
% figure;
% cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
% set(cdf1,'LineWidth',2,'LineStyle','-'); % Model Best Fit Stage
% hold on;
% cdf2=cdfplot(datastage(:,3));
% color2=[0.8500, 0.3250, 0.0980];
% set(cdf2,'LineWidth',2,'LineStyle','--','color',color2); % Data
% % hold on;
% % cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% % set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Unified Parameters
% % hold on;
% legend('Simulation','Data');