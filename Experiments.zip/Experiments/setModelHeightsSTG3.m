function setModelHeightsSTG3()
% xsa11=[4.6749;27.0331;8.8197;0.0023];
xsa18=[1.7249;26.8816;7.1235;0.0079];
[hh,rr]=returnParametersSTG2To3(xsa18);

global modelradiiSTG3
modelradiiSTG3=rr;
% N = size(Locations,1); 
global modelheightsSTG3
modelheightsSTG3=hh;

