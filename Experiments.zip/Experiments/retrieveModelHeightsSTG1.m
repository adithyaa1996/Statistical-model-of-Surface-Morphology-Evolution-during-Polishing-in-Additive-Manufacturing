function f=retrieveModelHeightsSTG1()
global modelheightsSTG1
f=modelheightsSTG1;