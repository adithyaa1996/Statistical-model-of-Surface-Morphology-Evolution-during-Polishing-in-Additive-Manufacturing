%% retrieve Heights unnormalised
function f=retrieveHeights()
global data
f=data;
