%% mainframe DO NOT EXECUTE AFTER FIRST TIME

% setSimHeightsSTG1(); % finalises initial heights for model. Uses a gamma fit on stage 0 data, then samples at random from fit

%% use randomcirclepacking to generate points
% [Locations, radii_m0] = random_circle_packing_rectangle([500 500],3.14,25,true);
% N=size(Locations,1);

%% Run file
% x0=[0.05;4;2.4;0.0045];% alpha, kappa_1,kappa_2,sigma
% x13=[0.18;8.75;1.5;0.0065];
x14=[3.5060;14.7457;0.8971;0.0263]; % xe2
x15=[4.3383;27.7050;9.0196;0.1220]; % xe1
xe7=[4.5759;20.5189;3.6134;0.0176]; % Low entropy 0.2813
xa1=[4.6959;19.5189;1.4134;0.0174]; % Low entropy 0.2662
x0=[0.18;8.75;1.5;0.0065]; %ver6SD 6.6855 ver7SD 11.0712 Works
% fh=evaluateObjectiveVer4(x);
xe12=[3.1681;12.8563;6.8582;0.0138];
ObjectiveFunction = @evalObjectiveStage1To2;
% x0 = [0.5 0.5];   % Starting point
% rng default % For reproducibility
lb=[0.01;0.5;0.1;0.00001];
ub=[20;40;10;0.04];
% options = optimoptions(@simulannealbnd,'MaxIterations',2,'FunctionTolerance',0.01);
% [x,fval,exitFlag,output] = simulannealbnd(ObjectiveFunction,x0,lb,ub); 
[xmin,fxmin]=simulatedAnnealingSolution(xe12,ObjectiveFunction,lb,ub);

%% Evaluate objective
for i=1:1:10    
    fh2=evaluateObjectiveVer5(x1);
    disp(fh2);
end
%% Experiment
x1=[0.3;3;0.7;0.0009];
x0=[0.32;5;0.5;0.0005];
x2=[0.32;5;0.5;0.0005];
x3=[0.3,1,1.9,0.001];
% x4=xmin;
x5=[0.05;4;2.4;0.0045];
x6=[0.14;10.5;1.3;0.0062];
x7=[0.75;4.5;0.4;0.0056];
% [fh3,h3]=evaluateObjectiveVer5(x7);
x8=[0.32;8;0.5;0.0027];
x9=[0.32;8.5;3.1;0.0076]; % best solution found so far 5.2388
x10=[0.32;7.5;2.9;0.0066];
x11=[0.323;8.95;3.15;0.0078];
x12=[0.05;4;2.4;0.0045]; % 5.9629
% [fh4,h4]=evaluateObjectiveVer6(x9);
% [fh5,h5]=evaluateObjectiveVer7(x9);
x13=[0.18;8.75;1.5;0.0065];

[fh5,h5]=evaluateObjectiveVer7(x14);
% [fh6,h6]=evaluateObjectiveVer6(x9);
%% New experiments
x1=[0.26;13.55;0.3;0.0065];% ver7SD 11.0816 delSD=2.3040 EN=10.3094 || 0.2987 
x2=[0.34;11.95;0.7;0.0069];% ver7SD 11.0811 delSD=2.2993 EN=10.3913 || 0.2987
x3=[0.34;11.95;0.3;0.0057];% ver7SD 10.9775 delSD=2.5126 EN=10.2237 || 0.3888
x4=[0.18;11.95;0.7;0.0053];% ver7SD 10.9602 delSD=2.4121 EN=10.2366 || 0.3307
x5=[0.22;11.95;0.7;0.0061];% ver7SD 11.0840 delSD=2.3281 EN=10.3856 || 0.3161
x6=[0.18;11.95;1.1;0.0057];% ver7SD 11.0821 delSD=2.3090 EN=10.3894 || 0.3105
x0=[0.18;8.75;1.5;0.0065]; %ver6SD 6.6855 ver7SD 11.0712 delSD=2.2006 EN=10.8511 Works || 0.3007
% Run Simanneal with x0 as base point for Ver6
xrandom=[0.3;10;2;0.002];
xrandom2=[0.3;10;2;0.004];
% Random Search Results with EN+0.5*SD
xrandom3=[6.2939;28.2784;1.9260;0.1169]; % ver7SD 5.3270 delSD=-3.8948 EN=3.3796
xrandom4=[9.8765;12.8268;0.2104;0.1169]; % ver7SD 5.3113 delSD=-3.8635 EN=3.3796
%[fh7,h7]=evaluateObjectiveVer7(xrandom2);
xe1=[4.3383;27.7050;9.0196;0.1220];% ver6SD 10^5 ver7SD 3.7899 delSD=-4.1038 EN=-0.3139
xe2=[3.5060;14.7457;0.8971;0.0263];% ver6SD 12.5914 ver7SD 11.3868 delSD=0.3460 EN=11.3522
xe3=[2.1152;27.2016;9.1577;0.1312];% ver6SD 10^5 ver7SD 6.0419
xe4=[7.8531;3.6902;9.5531;0.0108]; %ver6SD 6.6743 ver7SD 11.0503
xe5=[0.1244;25.9737;6.8109;0.0047];%ver6SD 8.7457 ver7SD 11.1582 Works
xe6=[1.5701;9.8505;2.1857;0.0106];%ver6SD 6.4169 ver7SD 11.0472 Works

xe7=[4.5759;20.5189;3.6134;0.0176]; % 0.2813
xe8=[4.1302;11.2968;4.7473;0.0211]; % 0.3227
xe9=[3.4885;27.1280;8.9494;0.0086]; % 0.3020
xe10=[4.6625;21.3615;6.7209;0.0154]; % 0.2794

xa1=[4.6959;19.5189;1.4134;0.0174]; % 0.2662 delSD=1.2025
xa2=[3.5060;14.7457;0.8971;0.0263]; % 0.4225 delSD=0.7981 
% [fh8,h8]=evaluateObjectiveVer7(xe2);
% [fh9,h9]=evaluateObjectiveVer7(xe2);
% [fh10,h10]=evaluateObjectiveVer8(xa1);
% [fh11,h11]=evalObjectiveStage1To2(xa1); 
% STAGE 2.. points with seed xa1
xe11=[5.7308;7.7822;2.2519;0.0147]; % 0.2331 delSD=0.1517
xe12=[3.1681;12.8563;6.8582;0.0138];% 0.2273 delSD=0.3809 <-- SA
xe14=[5.6850;8.4008;8.7162;0.0142];% 0.2272 delSD=0.3681
xe13=[6.4035;27.6710;8.2735;0.0069];% 0.2302 delSD=0.9939
xe14=[6.6065;19.6129;1.4876;0.0060];% 0.2212 delSD=0.3681
xe15=[];
x00=[0.16;6.75;1.5;0.00085]; % Guess point 0.2830 delSD= 1.5751
% STAGE 2.. points with seed x3
xe15=[2.7263;9.7820;7.5816;0.0159]; % 0.2247 <--SA
xe16=[];
[fh11,h11]=evalObjectiveStage1To2(xe14);
%% DelSD
delSD=std(max(h10(:,1501))-h10(:,1501))-std(datastage(:,2))
%% Newer Experiments from xe2
xe2_e1=[3.3260;17.7457;0.6971;0.0265]; %ver7SD 
xe2_e2=[3.4660;12.7457;1.0971;0.0267];
xe2_e3=[3.4660;14.7457;1.0971;0.0271];
xe2_e4=[3.4860;14.7457;1.0971;0.0267];
xe2_e5=[3.5060;14.7457;0.8971;0.0265];
xe2_e6=[3.3260;17.7457;0.6971;0.0265];

%% Plot
figure;
hist1=histogram(max(h11(:,1501))-h11(:,1501));
hist1.BinWidth=1;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,3));
hist2.BinWidth=1;
hist2.Normalization='probability';
%% Plot2
hist3=histogram(retrieveSimHeightsSTG1());
hist3.BinWidth=1;
hist3.Normalization='probability';
%% Plot3

figure;
hist1=histogram(retrieveSimHeightsSTG1());
hist1.BinWidth=1;
hist1.Normalization='probability';
hold;
hist2=histogram(datastageInv(:,2));
hist2.BinWidth=1;
hist2.Normalization='probability';
%% Entropy
delEN=fh9-0.5*abs(std(h9(:,1501))-std(datastageInv(:,2)));

%% Randomly select points
% min=100;
% min_x=zeros(4,1);
min_val=100000;
for counter=1:1:1000
    disp(counter);
    lb=[0.01;0.5;0.1;0.00001];
%     lb=[4;6;1;0.001];
    ub=[20;30;10;1];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand(4,1);
    [fh,hh]=evalObjectiveStage1To2(xrandom);
    if fh<min_val
        min_val=fh;
        min_x=xrandom;
    end
    disp(min_val);
end
disp(min_val);
disp(min_x);
% h0=histogram(datastageInv(:,2));
% h1=histogram(h7(:,1501));
