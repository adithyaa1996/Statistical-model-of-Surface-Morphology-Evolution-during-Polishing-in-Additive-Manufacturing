%% Define the objective function for simulated annealing

function [f,h]=evaluateObjectiveVer8(x)
% Retrieve Heights for stage0
% Heights will already be set using setGlobalheights in the mainframe
datastage=retrieveHeights();
% datastageInv=max(datastage)-datastage;
% normalise

% extract probability fit from stage0 data
% pd=fitdist(datastage(:,1),'Gamma');
% use probability distribution to generate heights for simulation

simheights=retrieveSimHeightsCP(); %  no need to call ver2 as simheights is global
simradiiCP=retrieveSimRadii();
N=size(simheights,1);
% radii = ones(N,1)*0.5 + rad,N,1);ndn(N,1)*0.05; % initial radii distribution

% initialise parameters for running dynamics
params = cell(1,2); 
% E = 1; dd = 0.01;
E=0.2;dd=0.1;
params{1} = E; params{2} = dd;
% Force = 1;
Force=44.48;
alpha = x(1);kappa_1 = x(2);kappa_2 = x(3);sigma = x(4);
speed = 0.53;
rho = 1;  
Time=300;
dt=0.2;
Horizon=0:dt:Time;
% initialise evolution parameters
T=zeros(N,length(Horizon)); T(:,1)=25*ones(N,1);T0=T(:,1);
h=zeros(N,length(Horizon)); h(:,1)=simheights;
r=zeros(N,length(Horizon)); r(:,1)=simradiiCP;
% r(:,1)=ones(N,1)*0.5 + min(randn(N,1),2)*0.05;
k = 2;
% dcrit=zeros(length(Horizon),1);
% F=zeros(N,1);
% Run dynamics

for t=dt:dt:Time    
    d_critical = solve_for_d(Force,r(:,k-1),h(:,k-1),params);
%     dcrit(k)=d_critical;
    F = zeros(N,1);
    active_nodes = find(h(:,k-1)>d_critical); % load bearing asperities
    F(active_nodes) = (2/3)*E*sqrt(r(active_nodes,k-1)).*(h(active_nodes,k-1)-d_critical*ones(length(active_nodes),1)).^1.5; % force carried by each node. 
    
    if ~isreal(F)
        f=1000000;
%         disp(k);
%         disp(h(:,k-1));
        return;
    end
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha*(T(:,k-1)-T0) + kappa_1*F + kappa_2*speed);
    h(:,k) = h(:,k-1) + dt*(-sigma*T(:,k-1).*F);   
    r(:,k) = r(:,k-1) + dt*(rho*sigma*T(:,k-1).*F);
    if min(h(:,k))<0 % failsafe against negative
        f=100000;
        return;        
    end
    k = k+1;
end
% call percentDivergence to evaluate objective
upperlevel=70;intervalWidth=1; % bin size reduced from 2 to 1 for this stage
f=percentDivergence(datastage(:,2),max(h(:,k-1))-h(:,k-1),upperlevel,intervalWidth);  
