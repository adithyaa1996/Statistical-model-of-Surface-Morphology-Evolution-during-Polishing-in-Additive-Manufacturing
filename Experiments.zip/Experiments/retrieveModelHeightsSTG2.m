function f=retrieveModelHeightsSTG2()
global modelheightsSTG2
f=modelheightsSTG2;