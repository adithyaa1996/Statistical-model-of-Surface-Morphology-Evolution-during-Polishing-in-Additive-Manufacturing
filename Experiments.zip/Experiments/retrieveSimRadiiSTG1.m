function f=retrieveSimRadiiSTG1()
global simradiiSTG1
f=simradiiSTG1;