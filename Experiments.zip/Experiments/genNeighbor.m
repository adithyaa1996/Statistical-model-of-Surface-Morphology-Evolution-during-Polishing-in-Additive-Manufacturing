%% generate Neighbors using stepsize
function [xprime,success]=genNeighbor(x,stepsize,lb,ub)
% This function creates a neighbor at random in the neighborhood of the
% original point x. The variable stepsize captures the maximum we can go in every
% dimension in directions both positve or negative. 
% lb - lower bound enforced for every dimension of x
% ub - upper bound enforced for every dimension of x
if (size(x)==size(stepsize)) & (size(stepsize)==size(lb)) & (size(lb)==size(ub))
    % pass
else
    success=0;
    xprime=x;
    return;
end
k=0;
while(k<=100)    
    deltax=(2*(rand(size(x))>0.5)-1).*stepsize;
    xprime=x+deltax;
    e=sum((xprime>=lb)&(xprime<=ub));
    if (e==length(x))
        % good, we have not violated any boundaries
        success=1;
        return;
    else
        % continue with the loop and find a acceptable neighbor
        k=k+1;
        
    end   
end
success=0;
xprime=x;

