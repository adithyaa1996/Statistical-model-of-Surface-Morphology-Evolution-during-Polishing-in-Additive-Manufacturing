function setSimHeightsSTG3()
% datastage=retrieveHeights();
% datastageInv=max(datastage)-datastage;
% xa1=[4.6959;19.5189;1.4134;0.0174];
% x3=[0.34;11.95;0.3;0.0057];
% x6=[0.18;11.95;1.1;0.0057];
% here's assuming the point being fed is a valid point

% perform simulation from stage1 to 2 using point
xe20=[4.7232;20.7438;4.1082;0.0154]; % 0.3320 delSD=-0.6981 SELECT STG3
xe14=[5.6850;8.4008;8.7162;0.0142]; 
[h,r]=returnHeightsRadiiStg2To3(xe20);


% pd=fitdist(datastageInv(:,1)+0.000001,'Weibull');
global simradiiSTG3
simradiiSTG3=r(:,3000);
% N = size(Locations,1); 
global simheightsSTG3
simheightsSTG3=h(:,3000);
