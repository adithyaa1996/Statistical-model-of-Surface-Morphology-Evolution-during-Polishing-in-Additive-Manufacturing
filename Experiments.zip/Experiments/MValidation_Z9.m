%% So where do we start from
% Model Validation needs work here.


%% Initialise heights,read heights SA+EN (30/70) *** Only perform this
setModelHeightsSTG1_parametric([sial4(1);1;1;sial4(2)]); % 
setModelHeightsSTG2_parametric([sial8(1);1;1;sial8(2)]); %
setModelHeightsSTG3_parametric([sial13(1);1;1;sial13(2)]); % Executed
setModelHeightsSTG4_parametric([sial17(1);1;1;sial17(2)]);
setModelHeightsSTG5_parametric([sial19(1);1;1;sial19(2)]);
setModelHeightsSTG6_parametric([sial21a(1);1;1;sial21a(2)]); % Is this function ready? YES
setModelHeightsSTG7_parametric([sial24a(1);1;1;sial24a(2)]); % Is this function ready? YES 
setModelHeightsSTG8_parametric([sial31a(1);1;1;sial31a(2)]); % Is this function ready? YES

%% Different values (Replace)
% % Solve for Entropy 70 SA 30
sial35=[4.51102275;0.00000197]; % 1.777 sa 2.7241 kld 1.3712 *****
sial36=[2.70946883;0.00001363]; % 1.8842 sa 2.7240 klD 1.5278
sial37=[7.93908762;0.00013966]; % 2.4879 sa 2.7236 klD 2.3869 bad
sial38=[9.41376587;0.00002457]; % 2 sa 2.7240 kld 1.7578
%% Evaluate
[funcVal,heightsForSACalc]=evalObjectiveStage8To9V2_Z(sial35,0.3,0.7);
%%
setModelHeightsSTG1();
setModelHeightsSTG2();
setModelHeightsSTG3();
xta1=[4.7101;23.5887;6.5008;0.0070]; %(sa 2.2327 klD 3.8623)
[funcValUF,heightsForSACalcUF]=evalObjectiveStage3To4V2_2(xta1,1,1);
%% Ideas for experiment design
lb=[0.01;0.5;0.1;0.00001];
ub=[20;40;10;0.04];
ObjectiveFunction = @evalObjectiveStage3To4V2_2;
[xmin,fxmin]=simulatedAnnealingSolution(xsa33,ObjectiveFunction,lb,ub); 

%% Average Objective value
f11=zeros(20,1);klD=zeros(20,1);
for j=1:1:20
    disp(j);
    [f,h]=evalObjectiveStage8To9V2_Z(sial38,1,0);
    f11(j)=f;
    klD(j)=percentDivergence(datastage(:,10),max(h)-h,70,0.1);
end
f11=mean(f11); klD=mean(klD);

%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:90000
    disp(counter);
    lb=[1;0.00000001];
%     lb=[4;6;1;0.001];
    ub=[10;1];
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand(2,1);
    [fh,hh]=evalObjectiveStage8To9V2_Z(xrandom,0.3,0.7);
    
    if fh<min_val 
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.3;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,10));
hist2.BinWidth=0.3;
hist2.Normalization='probability';
%%
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
set(cdf1,'LineWidth',2,'LineStyle','-'); % Model Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,10));
color2=[0.8500, 0.3250, 0.0980];
set(cdf2,'LineWidth',2,'LineStyle','--','color',color2); % Data
hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Unified Parameters
% hold on;
legend('Simulation','Data');

%% Plot overall
plot([5.9519 4.5928 3.1029 5.2017],[0.0067 0.0059 0.0026 0.0160])

%% Graphics module
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
color1=[0 0 0];
set(cdf1,'LineWidth',3.5,'LineStyle','-','color',color1); % Sigma Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,10));
% color2=[0.8500, 0.3250, 0.0980];
color2=[0 0 0];
set(cdf2,'LineWidth',3,'LineStyle','--','color',color2); % Data
xlabel('x','FontSize',18);
ylabel('F(x)','FontSize',18);

% hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Best Fit Parameters
% hold on;
lgd=legend('Simulation','Data');
lgd.FontSize=18;
title('')
set(gca,'FontSize',14);
% yh=get(gca,'ylabel');
% p34=get(yh,'position');
% p34(1)=-0.4+p34(1);
% set(yh,'position',p34);
