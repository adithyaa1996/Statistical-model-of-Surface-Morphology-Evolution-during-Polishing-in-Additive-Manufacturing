%% So where do we start from
% Stage0-stage1
% Step1: Initialise heights, read heights
% Step2: Apply modified dynamics
% Step3: Define the objective for the new height functions
% Step4: Find objective value

%% Initialise heights,read heights
% setGlobalHeights();
% datastage=retrieveHeights();

setModelHeightsSTG3(); %%Executed Oct11 1243pm

% setModelRadiiSTG3();
% heightsSTG3=retrieveModelHeightsSTG3();
% radiiSTG3=retrieveModelRadiiSTG3(); % Tested Okay Sep14 0802am
%%
% Run Dynamics
x00=[0.25;13.75;2.85;0.00085]; % sa 3.3004 klD 1.6599 
x01=[4.6959;19.5189;1.4134;0.0174]; % sa 0.2109 klD 3.9291 % previouspoint
xa0=[4.6959;19.5189;1.4134;0.0174]; % sa 0.2167 klD 3.9450
xerror=[136.9875;47.5298;37.4001;8.0837];
xerror2=[18.8369;19.1296;6.2094;0.6435];  
xa1=[3.9962;10.9157;2.2550;0.0033];
xa2=[6.7925;22.6070;2.8878;0.0039];% sa 2.9305 klD 1.5974 START SANNEAL
xa3=[1.7808;6.1431;9.9526;0.0034]; % sa 2.9005 klD 1.8867
xa4=[2.9152;13.2564;6.4356;0.0018];% sa 3.6752 klD 1.6330
xsa1=[9.9153;19.2939;9.4618;0.0154];%(0.0439,3.4572) true minimizer of SA values
xsa2=[4.5721;23.9753;4.9423;0.0124];% (sa 0.4949 klD 3.1997) 
xsa3=[1.7911;19.1566;8.1519;0.0018];%(sa 3.4179 klD 1.7504)
xsa4=[6.6924;24.1556;0.5508;0.0029];%(sa 3.2947 klD 1.5245)
xsa5=[4.3925;15.4070;2.8878;0.0111];%(sa 0.8669 klD 2.8179) *
xsa6=[4.3925;13.0070;1.6878;0.0087];%(sa 1.5226 klD 2.4140) *<-START SIMANNEAL, SELECTED
xsa7=[7.3925;23.8070;1.9878;0.0123];%(sa 0.6465 klD 3.0191) *
xsa8=[7.9925;5.8070;8.2878;0.0135];%(sa 0.4688 klD 3.1674) *
xsa9=[7.3925;9.4070;6.7878;0.0123];%(sa 0.6948 klD 3.0033) *
xsa10=[6.7925;15.4070;1.6878;0.0087];%(sa 0.6931 klD 2.9911)* 
xsa11=[4.6749;27.0331;8.8197;0.0023];
%% STAGE 1To2
xsa11=[4.6749;27.0331;8.8197;0.0023];%(sa 1.1137 klD 2.7566) <-START ANNEAL, SELECT
xsa12=[4.5361;25.9721;8.2089;0.0064];%(sa 0.2904 klD 3.5692) 
xsa13=[9.7502;25.8666;0.7986;0.0055];%(sa 0.5238 klD 3.1134)
xsa14=[5.3792;16.9729;5.4770;0.0054];%(sa 0.5147 klD 3.0206)
xsa15=[8.8066;5.5081;5.9936;0.0052];%(sa 0.5908 klD 3.0651)
%% STAGE 2To3
xsa16=[0.8288;18.5355;2.6749;0.0090];%(sa 1.5029 klD 4.1745)
xsa17=[9.6380;3.3825;9.5577;0.0051];%(sa 2.2338 klD 3.7135)
xsa18=[1.7249;26.8816;7.1235;0.0079];%(sa 1.6214 klD 3.8154)<-START ANNEAL 5.43, SELECT
xse19=[1.1249;23.2816;4.4235;0.0067];%(sa 1.7222 klD 4.4379) bad 6.1601
xsa20=[6.4565;9.1195;2.0947;0.0052];%(sa 2.2473 klD 3.786) 6.0333
xsa21=[8.8565;9.1195;0.8947;0.0028];%(sa 2.7390 klD 3.0812) good 5.8202
xsa22=[7.0565;0.7195;6.5947;0.0112];%(sa 1.4971 klD 4.2637) same 5.7608
xsa23=[9.4565;3.1195;4.7947;0.0112];%(sa 1.5042 klD 4.2187) same 5.7229
xsa24=[8.2565;27.1195;1.1947;0.0112];%(sa 1.4985 klD 4.1825)same 5.6810
xsa25=[2.8565;28.3195;1.4947;0.0028];%(sa 2.6862 klD 2.9988) good 5.6850
xsa26=[2.2565; 29.5195; 2.3947;0.0112];%(sa 1.4211 klD 4.2651) 5.6862
xsa27=[2.8565;18.7195;8.0947;0.0100];% (sa 1.5014 klD 4.0828) 5.5842
xsa28=[7.0565;17.5195;1.1947;0.0112];%(sa 1.4988 klD 4.0883) 5.5871
xsa29=[4.8443;25.8158;6.9134;0.0118];%

%% STAGE 3To4
xsa30=[4.3474;1.6447;5.1109;0.0083];%(sa 2.2241 klD 3.6749) 5.8990
xsa31=[3.6280;9.7648;6.1023;0.0087];%(sa 2.2233 klD 3.6542) 5.8775
xsa32=[6.5490;19.5572;9.9528;0.0086];%(sa 2.2237 klD 3.5187) 5.7424
xsa33=[8.0481;27.4332;8.3723;0.0092];%(sa 2.222 klD 3.2826) 5.5047 <-Start Anneal SELECT
% Assume best point
% Do a sharp very local search by playing with parameters
xsa34=[8.7521;22.1639;1.6855;0.0090];%(sa 2.2237 klD 3.5183) 5.7420
xsa35=[8.8885;26.8678;6.0672;0.0081];%(sa 2.2245 klD 3.6187 5.8432
xsa36=[2.8474;9.5761;5.0073;0.0086];%(sa 2.2235 klD 3.4727) 5.6962
xsa37=[2.9109;7.9226;5.8052;0.0084];%(sa 2.2237 klD 3.7035) 5.9272
xsa38=[1.5679;6.9348;8.9721;0.0071];%(sa 2.2241 klD 3.6769) 5.9010
xsa39=[1.0481;31.0332;9.0723;0.0064];%(sa 2.2221 klD 3.2840) 5.5060
xsa40=[4.0481;31.0332;9.0723;0.0064];%(sa 2.2293 klD 4.0033)6.2325 HP :D
% setModelHeightsSTG1();
% setModelHeightsSTG2();
% setModelHeightsSTG3();
%% Parametric

xb1sa1=[4.8362;1.2606;8.4801;0.0149];
% xb1sa2=[1.9791;23.9000;5.6571;0.0006];
xb1sa2=[4.3252;22.5148;2.2473;0.0017];
% xb1sa3=[3.4856;0.9376;2.9279;0.0074];
xb1sa3=[8.4355;5.6277;9.1323;0.0067];
% xb1sa4=[5.1862;12.1395;6.8178;0.0050];%(sa 2.2583 klD 7.2566)
xb1sa4=[1.7765;15.6196;8.9096;0.0081];%(sa 2.2193 klD 3.6709) comparable
xb2sa2=[5.6649;18.8655;2.1553;0.0015];
xb2sa3=[8.8376;11.0803;3.5260;0.0063];
xb2sa4=[8.88;10.3846;4.6568;0.0088];%(sa 2.2187 klD 3.7344)
xb3sa1=[7.8669;7.8736;3.3410;0.0153];
xb3sa2=[8.8084;8.6683;9.7842;0.0016];
xb3sa3=[2.4793;28.7921;7.2589;0.0059];
xb3sa4=[7.4545;24.7269;1.5175;0.0086];%(sa 2.2215 klD 3.5972)
xb4sa1=[0.8377;5.2884;4.8413;0.0119];
xb4sa2=[6.9028;20.4013;1.5655;0.0020];
xb4sa3=[6.7764;21.5818;0.5062;0.0093];
xb4sa4=[6.5093;18.6800;3.9933;0.0071];%(sa 2.2195 klD 3.2946)
setModelHeightsSTG3_parametric(xb2sa3);
%% Evaluate
[funcVal,heightsForSACalc]=evalObjectiveStage3To4V2_2(xsa33,1,1);
%%
setModelHeightsSTG1_Unified();
setModelHeightsSTG2_Unified();
setModelHeightsSTG3_Unified();
xta1=[4.7101;23.5887;6.5008;0.0070]; %(sa 2.2327 klD 3.8623)
[funcValUF,heightsForSACalcUF]=evalObjectiveStage3To4V2_2(xta1,1,1);
%% Ideas for experiment design
lb=[0.01;0.5;0.1;0.00001];
ub=[20;40;10;0.04];
ObjectiveFunction = @evalObjectiveStage3To4V2_2;
[xmin,fxmin]=simulatedAnnealingSolution(xsa33,ObjectiveFunction,lb,ub); 

%% Average Objective value
f11=zeros(20,1);klD=zeros(20,1);
for j=1:1:20
    disp(j);
    [f,h]=evalObjectiveStage3To4V2_2(xb4sa4,1,0);
    f11(j)=f;
    klD(j)=percentDivergence(datastage(:,5),max(h)-h,70,0.1);
end
f11=mean(f11); klD=mean(klD);

%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:4000
    disp(counter);
    lb=[0.01;0.5;0.1;0.00001];
%     lb=[4;6;1;0.001];
    ub=[20;30;10;1];
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand(4,1);
    [fh,hh]=evalObjectiveStage3To4V2_2(xrandom,1,1);
    
    if fh<min_val 
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.3;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,5));
hist2.BinWidth=0.3;
hist2.Normalization='probability';
%%
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
set(cdf1,'LineWidth',2,'LineStyle','-'); % Model Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,5));
color2=[0.8500, 0.3250, 0.0980];
set(cdf2,'LineWidth',2,'LineStyle','--','color',color2); % Data
hold on;
cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Unified Parameters
hold on;
legend('BestFit','Data','UnifiedFit');