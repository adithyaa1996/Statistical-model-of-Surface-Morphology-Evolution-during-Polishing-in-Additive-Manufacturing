%% Model Parameters Fitting with Shilan Jin's data - June 4th 2021

% Consider a 0.5mm x 0.5mm surface for the purpose of modelling.
% Surface packing density is assumed to lie between 0.7 and 0.9 based on
% the specified minimun and maximum radii value of asperities.
% what is the density (asperities/mm^2?)

% Placing asperities on a 2D space
[Locations, radii_m0] = random_circle_packing_rectangle([500 500],4.51,36,true);
x_pos = Locations(:,1);
y_pos = Locations(:,2);
% We have the x,y coordinates of the asperities, along with the radii
% Radii are in micrometer
figure; 
DT = delaunayTriangulation(x_pos, y_pos);
triplot(DT);
title('Surface Asperities - Network Formation');
xlabel('X (10^{-6})m')
ylabel('Y (10^{-6})m')
pub_fig;

N = size(Locations,1);  % number of asperities. Instead of fixing this, we are 
% inferring this value from the random circle packing. 
heights_m0 = wblrnd(45,4.9,[N 1]); % initial height distribution - weibull with mean ~ 24
% instead of going for Weibull distribution, use the distribution from the
% data itself

asperity_area = pi * sum(radii_m0.^2);  % units um^2
Temp = 25*ones(N,1);  % baseline temperature ???

% parameter initialisation
params = cell(1,2); 
E = 0.2;
dd = 0.01;
params{1} = E;
params{2} = dd;

Force = zeros(1,25);
alpha = zeros(1,25);
kappa_1 = zeros(1,25);
kappa_2 = zeros(1,25);
speed = zeros(1,25);
sigma = zeros(1,25);
rho = zeros(1,25);

%% Stage 0 - Data and Model Comparison

Table0 = readtable('matrix_stage0.csv');
data_stage0 = table2array(Table0);
data_stage0 = reshape(data_stage0, [3264 1]);
data0 = mean(data_stage0) - data_stage0; %%% okay? 

% Stage 0 Data Statistics
max_stage0 = max(data0);
mean_stage0 = mean(data0);
stdev_stage0 = std(data0);
min_stage0 = min(data0);
Hurst_stage0 = Gen_hurst(data0);
Sa_stage0 = 0;
for i = 1: 3264
    Sa_stage0 = Sa_stage0 + ((1/3264)*(abs(data0(i) - mean_stage0)));
end

% Model 0 Statistics
max_model_0 = max(heights_m0);
mean_model_0 = mean(heights_m0);
stdev_model_0 = std(heights_m0);
min_model_0 = min(heights_m0);
Hurst_model_0 = Gen_hurst(heights_m0);
Sa_model_0 = 0;
for i = 1: N
    Sa_model_0 = Sa_model_0 + ((1/(N))*(abs(heights_m0(i) - mean_model_0)));
end


figure
subplot(2,3,1)
histogram(data_stage0,20)
title('Histogram of Stage 0 Data');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,2)
[Values, edges] = histcounts(data_stage0, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values, centers, 'r-', 'LineWidth', 3)
title('BAC - Stage 0 Data')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_0 - heights_m0,20)
title('Histogram of Model 0 Sim');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,5)
[Values, edges] = histcounts(max_model_0 - heights_m0, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+ edges(2:end))/2;
plot(Values, centers, 'r-', 'LineWidth', 3);
title('BAC - Model 0 Sim');
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min'};
Stage_0 = [mean_stage0; stdev_stage0; Sa_stage0; max_stage0; min_stage0];
Model_0 = [mean_model_0; stdev_model_0; Sa_model_0; max_model_0; min_model_0];
T = table(Stage_0, Model_0, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

%% Stage 0 to Stage 1 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(1) = 44.48; % total load 
alpha(1) = 0.32; 
kappa_1(1) = 5;
kappa_2(1) = 0.5;
speed(1) = 0.53;
sigma(1) = 0.00018; 
rho(1) = 1;

Time = 300; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(1);
h = zeros(N,length(Horizon));  h(:,1) = heights_m0;
r = zeros(N,length(Horizon));  r(:,1) = radii_m0;
F = zeros(N,length(Horizon));  % Force carried by asperities

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(1),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(heights_m0 > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(1)*(T(:,k-1)- Temp) + kappa_1(1)*F(:, k-1) + kappa_2(1)*speed(1));
    
    for i = 1:1:N
        Indicator = ((7*Temp) > T(i,k-1)) & (T(i,k-1) > (1.5*Temp));
        s(i,k) = s(i,k-1) + (dt*Indicator(i)*rho(1)*s(i,k-1)*0.01); 
        h(i,k) = h(i,k-1) - (dt*s(i,k-1)*T(i,k-1)*F(i,k-1));
        r(i,k) = r(i,k-1) + (dt*rho(1)*s(i,k-1)*T(i,k-1)*F(i,k-1)); 
    end
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m1 = h(:,length(Horizon));
radii_m1 = r(:,length(Horizon));

% height, radii and Temp change plots
figure
subplot(1,2,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of active asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

% subplot(1,3,2)
% plot(Horizon,r(active_nodes,:),'LineWidth',2)
% pub_fig;
% hold on
% end
% title('Radii change dynamics of asperities')
% xlabel('Time (sec)')
% ylabel('Radii (um)')

subplot(1,2,2) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 1')
xlabel('Time (sec)')
ylabel('Temp (degree C)')

%% Stage 1 - Data and Model Comparison

Table1 = readtable('matrix_stage1.csv');
data_stage1 = table2array(Table1);
data_stage1 = reshape(data_stage1, [3264 1]);
data1 = mean(data_stage1) - data_stage1;

% Stage 1 Data Statistics
max_stage1 = max(data1);
mean_stage1 = mean(data1);
stdev_stage1 = std(data1);
min_stage1 = min(data1);
Hurst_stage1 = Gen_hurst(data1);
Sa_stage1 = 0;
for i = 1: 3264
    Sa_stage1 = Sa_stage1 + ((1/3264)*(abs(data_stage1(i) - mean_stage1)));
end

% Model 1 Statistics
max_model_1 = max(heights_m1);
mean_model_1 = mean(heights_m1);
stdev_model_1 = std(heights_m1);
min_model_1 = min(heights_m1);
Hurst_model_1 = Gen_hurst(heights_m1);
Sa_model_1 = 0;
for i = 1: N
    Sa_model_1 = Sa_model_1 + ((1/(N))*(abs(heights_m1(i) - mean_model_1)));
end

figure
subplot(2,3,1)
histogram(data_stage1,20)
title('Histogram of Stage 1 Data');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,2)
[Values, edges] = histcounts(data_stage1, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values, (centers), 'r-', 'LineWidth', 3)
title('BAC - Stage 1 Data')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_1 - heights_m1,20)
title('Histogram of Model 1 Sim');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,5)
[Values, edges] = histcounts(max_model_1 - heights_m1, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values,(centers), 'r-', 'LineWidth', 3)
title('BAC - Model 1 Sim')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min'};
Stage_1 = [mean_stage1; stdev_stage1; Sa_stage1; max_stage1; min_stage1];
Model_1 = [mean_model_1; stdev_model_1; Sa_model_1; max_model_1; min_model_1];
T = table(Stage_1, Model_1, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'};
Values_1 = [Force(1); alpha(1); kappa_1(1); kappa_2(1); sigma(1)*0.01];
T = table(Values_1, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 1');

vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);
[AdjMat_1, edge_prob_1] = graph_evolution(x_pos, y_pos, Force(1), r(:,length(Horizon)), h(:,length(Horizon)), heights_m0, params, vectorlength, 1);
    

%% Stage 1 to Stage 2 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(2) = 44.48; % total load 
alpha(2) = 0.30; 
kappa_1(2) = 5;
kappa_2(2) = 0.5;
speed(2) = 0.53;
sigma(2) = 0.00013; 
rho(2) = 1;

Time = 300; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(2);
h = zeros(N,length(Horizon));  h(:,1) = heights_m1;
r = zeros(N,length(Horizon));  r(:,1) = radii_m1;
F = zeros(N,length(Horizon));  % Force carried by asperities

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m1);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(2),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(heights_m1 > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(2)*(T(:,k-1)- Temp) + kappa_1(2)*F(:, k-1) + kappa_2(2)*speed(2));
    
    for i = 1:1:N
        Indicator = ((7*Temp) > T(i,k-1)) & (T(i,k-1) > (1.5*Temp));
        s(i,k) = s(i,k-1) + (dt*Indicator(i)*rho(2)*s(i,k-1)*0.01); 
        h(i,k) = h(i,k-1) - (dt*s(i,k-1)*T(i,k-1)*F(i,k-1));
        r(i,k) = r(i,k-1) + (dt*rho(2)*s(i,k-1)*T(i,k-1)*F(i,k-1)); 
    end
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m2 = h(:,length(Horizon));
radii_m2 = r(:,length(Horizon));

% height, radii and Temp change plots
figure
subplot(1,2,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

% subplot(1,3,2)
% plot(Horizon,r(active_nodes,:),'LineWidth',2)
% pub_fig;
% hold on
% end
% title('Radii change dynamics of asperities')
% xlabel('Time (sec)')
% ylabel('Radii (um)')

subplot(1,2,2) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 2')
xlabel('Time (sec)')
ylabel('Temp (degree C)')


%% Stage 2 - Data and Model Comparison

Table2 = readtable('matrix_stage2.csv');
data_stage2 = table2array(Table2);
data_stage2 = reshape(data_stage2, [3264 1]);
data2 = mean(data_stage2) - data_stage2;

% Stage 2 Data Statistics
max_stage2 = max(data2);
mean_stage2 = mean(data2);
stdev_stage2 = std(data2);
min_stage2 = min(data2);
Hurst_stage2 = Gen_hurst(data2);
Sa_stage2 = 0;
for i = 1: 3264
    Sa_stage2 = Sa_stage2 + ((1/3264)*(abs(data_stage2(i) - mean_stage2)));
end

% Model 2 Statistics
max_model_2 = max(heights_m2);
mean_model_2 = mean(heights_m2);
stdev_model_2 = std(heights_m2);
min_model_2 = min(heights_m2);
Hurst_model_2 = Gen_hurst(heights_m2);
Sa_model_2 = 0;
for i = 1: N
    Sa_model_2 = Sa_model_2 + ((1/(N))*(abs(heights_m2(i) - mean_model_2)));
end

figure
subplot(2,3,1)
histogram(data_stage2,20)
title('Histogram of Stage 2 Data');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,2)
[Values, edges] = histcounts(data_stage2, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values, (centers), 'r-', 'LineWidth', 3)
title('BAC - Stage 2 Data')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_2 - heights_m2,20)
title('Histogram of Model 2 Sim');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,5)
[Values, edges] = histcounts(max_model_2 - heights_m2, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values,(centers), 'r-', 'LineWidth', 3)
title('BAC - Model 2 Sim')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min'};
Stage_2 = [mean_stage2; stdev_stage2; Sa_stage2; max_stage2; min_stage2];
Model_2 = [mean_model_2; stdev_model_2; Sa_model_2; max_model_2; min_model_2];
T = table(Stage_2, Model_2, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'};
Values_2 = [Force(2); alpha(2); kappa_1(2); kappa_2(2); sigma(2)*0.01];
T = table(Values_2, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 2');

vector = 0: params{2}: max(heights_m1);
vectorlength = length(vector);
[AdjMat_2, edge_prob_2] = graph_evolution(x_pos, y_pos, Force(2), r(:,length(Horizon)), h(:,length(Horizon)), heights_m0, params, vectorlength, 2);
    


%% Stage 2 to Stage 3 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(3) = 44.48; % total load 
alpha(3) = 0.30; 
kappa_1(3) = 5;
kappa_2(3) = 0.5;
speed(3) = 0.53;
sigma(3) = 0.00013; 
rho(3) = 1;

Time = 300; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(3);
h = zeros(N,length(Horizon));  h(:,1) = heights_m2;
r = zeros(N,length(Horizon));  r(:,1) = radii_m2;
F = zeros(N,length(Horizon));  % Force carried by asperities

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m2);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(3),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(heights_m2 > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(3)*(T(:,k-1)- Temp) + kappa_1(3)*F(:, k-1) + kappa_2(3)*speed(3));
    
    for i = 1:1:N
        Indicator = ((7*Temp) > T(i,k-1)) & (T(i,k-1) > (1.5*Temp));
        s(i,k) = s(i,k-1) + (dt*Indicator(i)*rho(3)*s(i,k-1)*0.01); 
        h(i,k) = h(i,k-1) - (dt*s(i,k-1)*T(i,k-1)*F(i,k-1));
        r(i,k) = r(i,k-1) + (dt*rho(3)*s(i,k-1)*T(i,k-1)*F(i,k-1)); 
    end
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m3 = h(:,length(Horizon));
radii_m3 = r(:,length(Horizon));

% height, radii and Temp change plots
figure
subplot(1,2,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

% subplot(1,3,2)
% plot(Horizon,r(active_nodes,:),'LineWidth',2)
% pub_fig;
% hold on
% end
% title('Radii change dynamics of asperities')
% xlabel('Time (sec)')
% ylabel('Radii (um)')

subplot(1,2,2) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 3')
xlabel('Time (sec)')
ylabel('Temp (degree C)')

    
%% Stage 3 - Data and Model Comparison

Table3 = readtable('matrix_stage3.csv');
data_stage3 = table2array(Table3);
data_stage3 = reshape(data_stage3, [3264 1]);
data3 = mean(data_stage3) - data_stage3;

% Stage 3 Data Statistics
max_stage3 = max(data3);
mean_stage3 = mean(data3);
stdev_stage3 = std(data3);
min_stage3 = min(data3);
Hurst_stage3 = Gen_hurst(data3);
Sa_stage3 = 0;
for i = 1: 3264
    Sa_stage3 = Sa_stage3 + ((1/3264)*(abs(data_stage3(i) - mean_stage3)));
end

% Model 3 Statistics
max_model_3 = max(heights_m3);
mean_model_3 = mean(heights_m3);
stdev_model_3 = std(heights_m3);
min_model_3 = min(heights_m3);
Hurst_model_3 = Gen_hurst(heights_m3);
Sa_model_3 = 0;
for i = 1:1:N
    Sa_model_3 = Sa_model_3 + ((1/(N))*(abs(heights_m3(i) - mean_model_3)));
end

figure
subplot(2,3,1)
histogram(data_stage3,20)
title('Histogram of Stage 3 Data');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,2)
[Values, edges] = histcounts(data_stage3, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values, (centers), 'r-', 'LineWidth', 3)
title('BAC - Stage 3 Data')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_3 - heights_m3,20)
title('Histogram of Model 3 Sim');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,5)
[Values, edges] = histcounts(max_model_3 - heights_m3, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values,(centers), 'r-', 'LineWidth', 3)
title('BAC - Model 3 Sim')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min'};
Stage_3 = [mean_stage3; stdev_stage3; Sa_stage3; max_stage3; min_stage3];
Model_3 = [mean_model_3; stdev_model_3; Sa_model_3; max_model_3; min_model_3];
T = table(Stage_3, Model_3, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'};
Values_3 = [Force(3); alpha(3); kappa_1(3); kappa_2(3); sigma(3)*0.01];
T = table(Values_3, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 3');

vector = 0: params{2}: max(heights_m2);
vectorlength = length(vector);
[AdjMat_3, edge_prob_3] = graph_evolution(x_pos, y_pos, Force(3), r(:,length(Horizon)), h(:,length(Horizon)), heights_m0, params, vectorlength, 3);
    


%% Stage 3 to Stage 4 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(4) = 44.48; % total load 
alpha(4) = 0.30; 
kappa_1(4) = 5;
kappa_2(4) = 0.5;
speed(4) = 0.53;
sigma(4) = 0.00013; 
rho(4) = 1;

Time = 300; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(4);
h = zeros(N,length(Horizon));  h(:,1) = heights_m3;
r = zeros(N,length(Horizon));  r(:,1) = radii_m3;
F = zeros(N,length(Horizon));  % Force carried by asperities

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m3);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(4),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(heights_m3 > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(4)*(T(:,k-1)- Temp) + kappa_1(4)*F(:, k-1) + kappa_2(4)*speed(4));
    
    for i = 1:1:N
        Indicator = ((7*Temp) > T(i,k-1)) & (T(i,k-1) > (1.5*Temp));
        s(i,k) = s(i,k-1) + (dt*Indicator(i)*rho(4)*s(i,k-1)*0.01); 
        h(i,k) = h(i,k-1) - (dt*s(i,k-1)*T(i,k-1)*F(i,k-1));
        r(i,k) = r(i,k-1) + (dt*rho(4)*s(i,k-1)*T(i,k-1)*F(i,k-1)); 
    end
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m4 = h(:,length(Horizon));
radii_m4 = r(:,length(Horizon));

% height, radii and Temp change plots
figure
subplot(1,2,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

% subplot(1,3,2)
% plot(Horizon,r(active_nodes,:),'LineWidth',2)
% pub_fig;
% hold on
% end
% title('Radii change dynamics of asperities')
% xlabel('Time (sec)')
% ylabel('Radii (um)')

subplot(1,2,2) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 4')
xlabel('Time (sec)')
ylabel('Temp (degree C)')


%% Stage 4 - Data and Model Comparison

Table4 = readtable('matrix_stage4.csv');
data_stage4 = table2array(Table4);
data_stage4 = reshape(data_stage4, [3264 1]);
data4 = mean(data_stage4) - data_stage4;

% Stage 4 Data Statistics
max_stage4 = max(data4);
mean_stage4 = mean(data4);
stdev_stage4 = std(data4);
min_stage4 = min(data4);
Hurst_stage4 = Gen_hurst(data4);
Sa_stage4 = 0;
for i = 1: 3264
    Sa_stage4 = Sa_stage4 + ((1/3264)*(abs(data_stage4(i) - mean_stage4)));
end

% Model 4 Statistics
max_model_4 = max(heights_m4);
mean_model_4 = mean(heights_m4);
stdev_model_4 = std(heights_m4);
min_model_4 = min(heights_m4);
Hurst_model_4 = Gen_hurst(heights_m4);
Sa_model_4 = 0;
for i = 1:1:N
    Sa_model_4 = Sa_model_4 + ((1/(N))*(abs(heights_m4(i) - mean_model_4)));
end

figure
subplot(2,3,1)
histogram(data_stage4,20)
title('Histogram of Stage 4 Data');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,2)
[Values, edges] = histcounts(data_stage4, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values, (centers), 'r-', 'LineWidth', 3)
title('BAC - Stage 4 Data')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_4 - heights_m4,20)
title('Histogram of Model 4 Sim');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,5)
[Values, edges] = histcounts(max_model_4 - heights_m4, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values,(centers), 'r-', 'LineWidth', 3)
title('BAC - Model 4 Sim')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min'};
Stage_4 = [mean_stage4; stdev_stage4; Sa_stage4; max_stage4; min_stage4];
Model_4 = [mean_model_4; stdev_model_4; Sa_model_4; max_model_4; min_model_4];
T = table(Stage_4, Model_4, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'};
Values_4 = [Force(4); alpha(4); kappa_1(4); kappa_2(4); sigma(4)*0.01];
T = table(Values_4, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 4');

vector = 0: params{2}: max(heights_m3);
vectorlength = length(vector);
[AdjMat_4, edge_prob_4] = graph_evolution(x_pos, y_pos, Force(4), r(:,length(Horizon)), h(:,length(Horizon)), heights_m0, params, vectorlength, 4);
 

%% Stage 4 to Stage 5 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(5) = 44.48; % total load 
alpha(5) = 0.30; 
kappa_1(5) = 5;
kappa_2(5) = 0.5;
speed(5) = 0.53;
sigma(5) = 0.00013; 
rho(5) = 1;

Time = 600; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(5);
h = zeros(N,length(Horizon));  h(:,1) = heights_m4;
r = zeros(N,length(Horizon));  r(:,1) = radii_m4;
F = zeros(N,length(Horizon));  % Force carried by asperities

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m4);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(5),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(heights_m4 > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(5)*(T(:,k-1)- Temp) + kappa_1(5)*F(:, k-1) + kappa_2(5)*speed(5));
    
    for i = 1:1:N
        Indicator = ((7*Temp) > T(i,k-1)) & (T(i,k-1) > (1.5*Temp));
        s(i,k) = s(i,k-1) + (dt*Indicator(i)*rho(5)*s(i,k-1)*0.01); 
        h(i,k) = h(i,k-1) - (dt*s(i,k-1)*T(i,k-1)*F(i,k-1));
        r(i,k) = r(i,k-1) + (dt*rho(5)*s(i,k-1)*T(i,k-1)*F(i,k-1)); 
    end
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m5 = h(:,length(Horizon));
radii_m5 = r(:,length(Horizon));

% height, radii and Temp change plots
figure
subplot(1,2,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

% subplot(1,3,2)
% plot(Horizon,r(active_nodes,:),'LineWidth',2)
% pub_fig;
% hold on
% end
% title('Radii change dynamics of asperities')
% xlabel('Time (sec)')
% ylabel('Radii (um)')

subplot(1,2,2) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 5')
xlabel('Time (sec)')
ylabel('Temp (degree C)')


%% Stage 5 - Data and Model Comparison

Table5 = readtable('matrix_stage5.csv');
data_stage5 = table2array(Table5);
data_stage5 = reshape(data_stage5, [3264 1]);
data5 = mean(data_stage5) - data_stage5;

% Stage 5 Data Statistics
max_stage5 = max(data5);
mean_stage5 = mean(data5);
stdev_stage5 = std(data5);
min_stage5 = min(data5);
Hurst_stage5 = Gen_hurst(data5);
Sa_stage5 = 0;
for i = 1: 3264
    Sa_stage5 = Sa_stage5 + ((1/3264)*(abs(data_stage5(i) - mean_stage5)));
end

% Model 5 Statistics
max_model_5 = max(heights_m5);
mean_model_5 = mean(heights_m5);
stdev_model_5 = std(heights_m5);
min_model_5 = min(heights_m5);
Hurst_model_5 = Gen_hurst(heights_m5);
Sa_model_5 = 0;
for i = 1:1:N
    Sa_model_5 = Sa_model_5 + ((1/(N))*(abs(heights_m5(i) - mean_model_5)));
end

figure
subplot(2,3,1)
histogram(data_stage5,20)
title('Histogram of Stage 5 Data');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,2)
[Values, edges] = histcounts(data_stage5, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values, (centers), 'r-', 'LineWidth', 3)
title('BAC - Stage 5 Data')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_5 - heights_m5,20)
title('Histogram of Model 5 Sim');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,5)
[Values, edges] = histcounts(max_model_5 - heights_m5, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values,(centers), 'r-', 'LineWidth', 3)
title('BAC - Model 5 Sim')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min'};
Stage_5 = [mean_stage5; stdev_stage5; Sa_stage5; max_stage5; min_stage5];
Model_5 = [mean_model_5; stdev_model_5; Sa_model_5; max_model_5; min_model_5];
T = table(Stage_5, Model_5, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'};
Values_5 = [Force(5); alpha(5); kappa_1(5); kappa_2(5); sigma(5)*0.01];
T = table(Values_5, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 5');

vector = 0: params{2}: max(heights_m4);
vectorlength = length(vector);
[AdjMat_5, edge_prob_5] = graph_evolution(x_pos, y_pos, Force(5), r(:,length(Horizon)), h(:,length(Horizon)), heights_m0, params, vectorlength, 5);
 

%% Stage 5 to Stage 6 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

Force(6) = 44.48; % total load 
alpha(6) = 0.30; 
kappa_1(6) = 5;
kappa_2(6) = 0.5;
speed(6) = 0.53;
sigma(6) = 0.00013; 
rho(2) = 1;

Time = 900; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(6);
h = zeros(N,length(Horizon));  h(:,1) = heights_m5;
r = zeros(N,length(Horizon));  r(:,1) = radii_m5;
F = zeros(N,length(Horizon));  % Force carried by asperities

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m5);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(6),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(heights_m1 > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(6)*(T(:,k-1)- Temp) + kappa_1(6)*F(:, k-1) + kappa_2(6)*speed(6));
    
    for i = 1:1:M+N
        Indicator = ((7*Temp) > T(i,k-1)) & (T(i,k-1) > (1.5*Temp));
        s(i,k) = s(i,k-1) + (dt*Indicator(i)*rho(6)*s(i,k-1)*0.01); 
        h(i,k) = h(i,k-1) - (dt*s(i,k-1)*T(i,k-1)*F(i,k-1));
        r(i,k) = r(i,k-1) + (dt*rho(6)*s(i,k-1)*T(i,k-1)*F(i,k-1)); 
    end
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m6 = h(:,length(Horizon));
radii_m6 = r(:,length(Horizon));

% height, radii and Temp change plots
figure
subplot(1,2,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

% subplot(1,3,2)
% plot(Horizon,r(active_nodes,:),'LineWidth',2)
% pub_fig;
% hold on
% end
% title('Radii change dynamics of asperities')
% xlabel('Time (sec)')
% ylabel('Radii (um)')

subplot(1,2,2) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 6')
xlabel('Time (sec)')
ylabel('Temp (degree C)')


%% Stage 6 - Data and Model Comparison

Table6 = readtable('matrix_stage6.csv');
data_stage6 = table2array(Table6);
data_stage6 = reshape(data_stage6, [3264 1]);
data6 = mean(data_stage6) - data_stage6;

% Stage 6 Data Statistics
max_stage6 = max(data6);
mean_stage6 = mean(data6);
stdev_stage6 = std(data6);
min_stage6 = min(data6);
Hurst_stage6 = Gen_hurst(data6);
Sa_stage6 = 0;
for i = 1:1:3264
    Sa_stage6 = Sa_stage6 + ((1/3264)*(abs(data_stage6(i) - mean_stage6)));
end

% Model 6 Statistics
max_model_6 = max(heights_m6);
mean_model_6 = mean(heights_m6);
stdev_model_6 = std(heights_m6);
min_model_6 = min(heights_m6);
Hurst_model_6 = Gen_hurst(heights_m6);
Sa_model_6 = 0;
for i = 1:1:N
    Sa_model_6 = Sa_model_6 + ((1/(N))*(abs(heights_m6(i) - mean_model_6)));
end

figure
subplot(2,3,1)
histogram(data_stage6,20)
title('Histogram of Stage 6 Data');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,2)
[Values, edges] = histcounts(data_stage6, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values, (centers), 'r-', 'LineWidth', 3)
title('BAC - Stage 6 Data')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_6 - heights_m6,20)
title('Histogram of Model 6 Sim');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,5)
[Values, edges] = histcounts(max_model_6 - heights_m6, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values,(centers), 'r-', 'LineWidth', 3)
title('BAC - Model 6 Sim')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min'};
Stage_6 = [mean_stage6; stdev_stage6; Sa_stage6; max_stage6; min_stage6];
Model_6 = [mean_model_6; stdev_model_6; Sa_model_6; max_model_6; min_model_6];
T = table(Stage_6, Model_6, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'};
Values_6 = [Force(6); alpha(6); kappa_1(6); kappa_2(6); sigma(6)*0.01];
T = table(Values_6, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 6');

vector = 0: params{2}: max(heights_m6);
vectorlength = length(vector);
[AdjMat_6, edge_prob_6] = graph_evolution(x_pos, y_pos, Force(6), r(:,length(Horizon)), h(:,length(Horizon)), heights_m0, params, vectorlength, 6);
 
















%% Parameter Plotting

figure
subplot(1,2,1)
stages = 1:1:6;
plot(stages, alpha(stages), 'b', 'Linewidth', 1.5)
hold on
plot(stages, sigma(stages), 'r', 'Linewidth', 2)
pub_fig;

subplot(1,2,2)
plot(stages, kappa_1(stages), 'g', 'Linewidth', 1.5)
hold on
plot(stages, kappa_2(stages), 'y', 'Linewidth', 1.5)
pub_fig;