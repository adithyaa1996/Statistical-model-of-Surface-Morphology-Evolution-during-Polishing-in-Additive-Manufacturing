%% mainframe DO NOT EXECUTE AFTER FIRST TIME
% setGlobalHeights(); % inputs all the data from csv
% setSimHeights(); % finalises initial heights for model. Uses a gamma fit on stage 0 data, then samples at random from fit
%% Run file
x0=[0.32;5;0.5;0.0005];% alpha, kappa_1,kappa_2,sigma
% fh=evaluateObjectiveVer4(x);
ObjectiveFunction = @evaluateObjectiveVer4;
% x0 = [0.5 0.5];   % Starting point
% rng default % For reproducibility
lb=[0.28;1;0.3;0.0001];
ub=[0.37;9;2.0;0.001];
% options = optimoptions(@simulannealbnd,'MaxIterations',2,'FunctionTolerance',0.01);
% [x,fval,exitFlag,output] = simulannealbnd(ObjectiveFunction,x0,lb,ub); 
[xmin,fxmin]=simulatedAnnealingSolution(x0,ObjectiveFunction,lb,ub);
%% Evaluate objective
x1=[0.3;3;0.7;0.0009];
fh2=evaluateObjectiveVer4(x1);