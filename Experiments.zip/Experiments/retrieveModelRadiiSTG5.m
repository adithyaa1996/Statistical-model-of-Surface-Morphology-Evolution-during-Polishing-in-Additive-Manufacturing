function f=retrieveModelRadiiSTG5()
global modelradiiSTG5;
f=modelradiiSTG5;
