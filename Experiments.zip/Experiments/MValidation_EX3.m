%% So where do we start from
% Stage0-stage1
% Step1: Initialise heights, read heights
% Step2: Apply modified dynamics
% Step3: Define the objective for the new height functions
% Step4: Find objective value

%% Initialise heights,read heights
% setGlobalHeights();
% datastage=retrieveHeights();

setModelHeightsSTG2(); %%Executed Oct8 1243pm
%%
sigmax0=0.01615719; % (sa  0.0296 klD 3.6006) <-Selected
sigmax1=0.00285666; % (sa 3.3667 klD 1.6033)
xaug1=[1;1;1;sigmax0];
sigmax2=0.00024036;
xaug2=[1;1;1;sigmax2];
% 
% setModelHeightsSTG1_parametric(xaug1);
% setModelHeightsSTG2_parametric(xaug2);
sigmax3=0.00852102; %(sa 1.4963 klD 4.1015)
sigmax3cand2=0.01207429; %(sa 1.5009 klD 4.2127)
sigmax3cand3=0.01045951; % (sa klD)
%% Evaluate
[funcVal,heightsForSACalc]=evalObjectiveStage2To3V2_EX(sigmax3,1,1);
%% Evaluate
xta1=[4.7101;23.5887;6.5008;0.0070];% (sa 1.6832 klD 4.3429)
setModelHeightsSTG1();
setModelHeightsSTG2(); 
[funcValUF,heightsForSACalcUF]=evalObjectiveStage2To3V2_2(xsa33,1,1);
%% Ideas for experiment design
lb=0.00001;
ub=1;
ObjectiveFunction = @evalObjectiveStage2To3V2_EX;

[xmin,fxmin]=simulatedAnnealingSolutionEX(sigmax3cand,ObjectiveFunction,lb,ub);

%% Average Objective value
f11=zeros(10,1);klD=zeros(10,1);
for j=1:1:10
    disp(j);
    [f,h]=evalObjectiveStage2To3V2_EX(sigmax3,1,0);
    f11(j)=f;
    klD(j)=percentDivergence(datastage(:,4),max(h)-h,70,0.1);
end
f11=mean(f11); klD=mean(klD);

%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:2000
    disp(counter);
    lb=0.00000001;
%     lb=[4;6;1;0.001];
    ub=1;
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand;
    [fh,hh]=evalObjectiveStage2To3V2_EX(xrandom,1,1);
    
    if fh<min_val
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.4;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,4));
hist2.BinWidth=0.4;
hist2.Normalization='probability';
%% Plot2
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
set(cdf1,'LineWidth',2,'LineStyle','-'); %Model Best Fit Stage
hold;
cdf2=cdfplot(datastage(:,4));
color2=[0.8500, 0.3250, 0.0980];
set(cdf2,'LineWidth',2,'LineStyle','--','color',color2); % Data
hold;
%% Plot3
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
set(cdf1,'LineWidth',2,'LineStyle','-'); % Model Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,4));
color2=[0.8500, 0.3250, 0.0980];
set(cdf2,'LineWidth',2,'LineStyle','--','color',color2); % Data
hold on;
cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Unified Parameters
hold on;
legend('SigmaFit','Data','ParametricFit');

