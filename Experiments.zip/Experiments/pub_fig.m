
% xlabel('X')
% ylabel('y')
axis tight
grid on
set(gca,'FontSize',12)
set(gca,'LineWidth',3)
set(gcf,'Color','w')
set(gca,'YGrid','on')
set(gca,'XGrid','on')
set(gca, 'Layer', 'Top')
set(gca, 'FontName', 'Arial','FontWeight','bold')

movegui('center');
