%% mainframe
setGlobalHeights();
x=[0.32;5;0.5;0.000080];% alpha, kappa_1,kappa_2,sigma
[fh,hstage,hsimulated]=evaluateObjectiveOld(x);
% ObjectiveFunction = @simple_objective;
% x0 = [0.5 0.5];   % Starting point
% rng default % For reproducibility
% [x,fval,exitFlag,output] = simulannealbnd(ObjectiveFunction,x0);