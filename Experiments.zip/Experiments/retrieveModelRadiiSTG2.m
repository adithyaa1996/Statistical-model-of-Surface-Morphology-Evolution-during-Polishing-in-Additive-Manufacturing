function f=retrieveModelRadiiSTG2()
global modelradiiSTG2;
f=modelradiiSTG2;
