%% Define the objective function for simulated annealing

function f=evaluateObjectiveVer4(x)
% Retrieve Heights for stage0
% Heights will already be set using setGlobalheights in the mainframe
datastage=retrieveHeights();
% extract probability fit from stage0 data
% pd=fitdist(datastage(:,1),'Gamma');
% use probability distribution to generate heights for simulation
N=50;
simheights=retrieveSimHeights();
% radii = ones(N,1)*0.5 + rad,N,1);ndn(N,1)*0.05; % initial radii distribution

% initialise parameters for running dynamics
params = cell(1,2); 
% E = 1; dd = 0.01;
E=0.2;dd=0.01;
params{1} = E; params{2} = dd;
% Force = 1;
Force=44.48;
alpha = x(1);kappa_1 = x(2);kappa_2 = x(3);sigma = x(4);
speed = 0.53;
rho = 1;  
Time=300;
dt=0.2;
Horizon=0:dt:Time;
% initialise evolution parameters
T=zeros(N,length(Horizon)); T(:,1)=25*ones(N,1);T0=T(:,1);
h=zeros(N,length(Horizon)); h(:,1)=simheights;
r=zeros(N,length(Horizon)); r(:,1)=ones(N,1)*0.5 + randn(N,1)*0.05;
k = 2;
% F=zeros(N,1);
% Run dynamics

for t=dt:dt:Time    
    d_critical = solve_for_d(Force,r(:,k-1),h(:,k-1),params);
    F = zeros(N,1);
    active_nodes = find(simheights>d_critical); % load bearing asperities
    F(active_nodes) = (2/3)*E*sqrt(r(active_nodes,k-1)).*(h(active_nodes,k-1)-d_critical*ones(length(active_nodes),1)).^1.5; % force carried by each node. 
    
    if ~isreal(F)
        f=100000;
        return;
    end
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha*(T(:,k-1)-T0) + kappa_1*F + kappa_2*speed);
    h(:,k) = h(:,k-1) + dt*(-sigma*T(:,k-1).*F);
    % Failsafe against negative. Need to come up
    % with robust solutions later
    if min(h(:,k))<=0.05 
        % conditions lead to premature polished surface. 
        % We enforce 300 timesteps for polishing from stage0 to stage1. 
        % break out with a high value of objective, to move away from such
        % points in the search space
        f=100000;
        return;
        
    end
    
    r(:,k) = r(:,k-1) + dt*(rho*sigma*T(:,k-1).*F);
    k = k+1;
end
% call kldiv to evaluate objective
% Now with the dynamics in place, the final height distribution is h(:,2)
pdstage1=fitdist(datastage(:,2),'Gamma');
if min(h(:,k-1))<0
    f=1;
    return;
end

pdsimulated=fitdist(h(:,k-1),'Gamma');
vectorC=0.5:0.5:(max(max(datastage(:,2)),max(h(:,k-1)))+5);
pdfstage1=pdf(pdstage1,vectorC); pdfstage1=pdfstage1/sum(pdfstage1);
pdfsimulated=pdf(pdsimulated,vectorC); pdfsimulated=pdfsimulated/sum(pdfsimulated);
f=kldiv(vectorC,pdfstage1,pdfsimulated,'js');
% print('Success');
% hstage=datastage(:,2);
% hsimulated=h(:,2);
% histogram(datastage(:,2));
% title('datastage, Stage1')
% figure;
% histogram(h(:,2));
% title('SimulatedHeights, Stage1');

