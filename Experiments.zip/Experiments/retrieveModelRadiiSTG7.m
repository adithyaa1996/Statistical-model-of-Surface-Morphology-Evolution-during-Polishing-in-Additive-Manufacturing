function f=retrieveModelRadiiSTG7()
global modelradiiSTG7;
f=modelradiiSTG7;
