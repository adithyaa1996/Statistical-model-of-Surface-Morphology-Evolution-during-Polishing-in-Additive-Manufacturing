function f=retrieveStageRadiiSTG0()
global modelRadiiSTG0;
f=modelRadiiSTG0;
