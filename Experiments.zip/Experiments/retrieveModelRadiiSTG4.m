function f=retrieveModelRadiiSTG4()
global modelradiiSTG4;
f=modelradiiSTG4;
