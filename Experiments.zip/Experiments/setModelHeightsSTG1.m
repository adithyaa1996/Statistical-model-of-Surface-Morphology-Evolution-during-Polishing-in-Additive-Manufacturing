function setModelHeightsSTG1()
xsa6=[4.3925;13.0070;1.6878;0.0087];
[hh,rr]=returnParametersSTG0To1(xsa6);

global modelradiiSTG1
modelradiiSTG1=rr;
% N = size(Locations,1); 
global modelheightsSTG1
modelheightsSTG1=hh;

