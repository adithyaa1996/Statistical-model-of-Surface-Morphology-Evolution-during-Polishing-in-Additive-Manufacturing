function f=retrieveSimRadii()
global simradiiCP
f=simradiiCP;