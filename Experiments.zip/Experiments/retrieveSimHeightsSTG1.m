function f=retrieveSimHeightsSTG1()
global simheightsSTG1
f=simheightsSTG1;

