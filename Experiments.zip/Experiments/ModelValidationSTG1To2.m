%% So where do we start from
% Stage0-stage1
% Step1: Initialise heights, read heights
% Step2: Apply modified dynamics
% Step3: Define the objective for the new height functions
% Step4: Find objective value

%% Initialise heights,read heights
% setGlobalHeights();
% datastage=retrieveHeights();

setModelHeightsSTG1(); %%Executed Oct11 1242pm

% setModelRadiiSTG1();
% heightsSTG1=retrieveModelHeightsSTG1();
% radiiSTG1=retrieveModelRadiiSTG1();
%%
% Run Dynamics
x00=[0.25;13.75;2.85;0.00085]; % sa 3.3004 klD 1.6599 
x01=[4.6959;19.5189;1.4134;0.0174]; % sa 0.2109 klD 3.9291 % previouspoint
xa0=[4.6959;19.5189;1.4134;0.0174]; % sa 0.2167 klD 3.9450
xerror=[136.9875;47.5298;37.4001;8.0837];
xerror2=[18.8369;19.1296;6.2094;0.6435];  
xa1=[3.9962;10.9157;2.2550;0.0033];
xa2=[6.7925;22.6070;2.8878;0.0039];% sa 2.9305 klD 1.5974 START SANNEAL
xa3=[1.7808;6.1431;9.9526;0.0034]; % sa 2.9005 klD 1.8867
xa4=[2.9152;13.2564;6.4356;0.0018];% sa 3.6752 klD 1.6330
xsa1=[9.9153;19.2939;9.4618;0.0154];%(0.0439,3.4572) true minimizer of SA values
xsa2=[4.5721;23.9753;4.9423;0.0124];% (sa 0.4949 klD 3.1997) 
xsa3=[1.7911;19.1566;8.1519;0.0018];%(sa 3.4179 klD 1.7504)
xsa4=[6.6924;24.1556;0.5508;0.0029];%(sa 3.2947 klD 1.5245)
xsa5=[4.3925;15.4070;2.8878;0.0111];%(sa 0.8669 klD 2.8179) *
xsa6=[4.3925;13.0070;1.6878;0.0087];%(sa 1.5226 klD 2.4140) *<-START SIMANNEAL, SELECTED
xsa7=[7.3925;23.8070;1.9878;0.0123];%(sa 0.6465 klD 3.0191) *
xsa8=[7.9925;5.8070;8.2878;0.0135];%(sa 0.4688 klD 3.1674) *
xsa9=[7.3925;9.4070;6.7878;0.0123];%(sa 0.6948 klD 3.0033) *
xsa10=[6.7925;15.4070;1.6878;0.0087];%(sa 0.6931 klD 2.9911)* 
% xsa11=[4.6749;27.0331;8.8197;0.0023];
%% STAGE 1To2
xsa11=[4.6749;27.0331;8.8197;0.0023];%(sa 1.1137 klD 2.7566) <-START ANNEAL, SELECT
xsa12=[4.5361;25.9721;8.2089;0.0064];%(sa 0.2904 klD 3.5692) 
xsa13=[9.7502;25.8666;0.7986;0.0055];%(sa 0.5238 klD 3.1134)
xsa14=[5.3792;16.9729;5.4770;0.0054];%(sa 0.5147 klD 3.0206)
xsa15=[8.8066;5.5081;5.9936;0.0052];%(sa 0.5908 klD 3.0651)
xta1=[4.7101;23.5887;6.5008;0.0070];%(sa 0.4124 klD 3.5368)
% setModelHeightsSTG1();
%% Parametric 
xb1sa1=[4.8362;1.2606;8.4801;0.0149];
xb2sa1=[0.2289;26.9341;5.3117;0.0043];
% xb1sa2=[1.9791;23.9000;5.6571;0.0006];
xb1sa2=[4.3252;22.5148;2.2473;0.0017]; % (sa 0.1164 klD 3.5097)
xb1sa2demo=[5.6979;7.4148;5.4887;0.0004];%(sa 0.3342 klD 3.3967)
xb2sa2=[5.6649;18.8655;2.1553;0.0015];%(sa 0.0280  klD 3.7134 )
xb3sa1=[7.8669;7.8736;3.3410;0.0153];
xb3sa2=[8.8084;8.6683;9.7842;0.0016];%(sa 0.1458 klD 3.5892)
xb4sa1=[0.8377;5.2884;4.8413;0.0119];
xb4sa2=[6.9028;20.4013;1.5655;0.0020];%(sa 0.1415 klD 3.6822)
xb5sa1=[1.91351962;28.66913969;4.97522015;0.00858582];
% setModelHeightsSTG1_parametric(xb5sa1);

%% Evaluate
[funcVal,heightsForSACalc]=evalObjectiveStage1To2V2_2(xb1sa2,1,1); 
%%
setModelHeightsSTG1_Unified(); % Executed Oct19
[funcValUF,heightsForSACalcUF]=evalObjectiveStage1To2V2_2(xta1,1,1);
%% Ideas for experiment design

lb=[0.01;0.5;0.1;0.00001];
ub=[20;40;10;0.04];
ObjectiveFunction = @evalObjectiveStage1To2V2_2;

[xmin,fxmin]=simulatedAnnealingSolution(xsa11,ObjectiveFunction,lb,ub);

%% Average Objective value
f11=zeros(20,1);klD=zeros(20,1);
for j=1:1:20
    disp(j);
    [f,h]=evalObjectiveStage1To2V2_2(xb4sa2,1,0);
    f11(j)=f;
    klD(j)=percentDivergence(datastage(:,3),max(h)-h,70,0.1);
end
f11=mean(f11); klD=mean(klD);

%% Difference in KLDiv
upperlevel=70;intervalWidth=0.1;
kldiv=percentDivergence(datastage(:,2),max(heightsForSACalc)-heightsForSACalc,upperlevel,intervalWidth);
disp(kldiv);
%% Difference in SA values

mean_model = mean(heightsForSACalc);
M = length(heightsForSACalc);
Sa_model = (1/M)*sum(abs(heightsForSACalc - mean_model),1);% use same formula 

mean_data=mean(datastage(:,2));
Sa_data=(1/length(datastage(:,2)))*sum(abs(datastage(:,2)-mean_data),1);
diffSA=abs(Sa_model-Sa_data);
disp(diffSA);
%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:4000
    disp(counter);
    lb=[0.01;0.5;0.1;0.00001];
%     lb=[4;6;1;0.001];
    ub=[20;30;10;1];
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand(4,1);
    [fh,hh]=evalObjectiveStage1To2V2_2(xrandom,1,1);
    
    if fh<min_val
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.5;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,3));
hist2.BinWidth=0.5;
hist2.Normalization='probability';
%% Plot
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
set(cdf1,'LineWidth',2,'LineStyle','-'); % Model Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,3));
color2=[0.8500, 0.3250, 0.0980];
set(cdf2,'LineWidth',2,'LineStyle','--','color',color2); % Data
hold on;
cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Unified Parameters
hold on;
legend('BestFit','Data','UnifiedFit');
