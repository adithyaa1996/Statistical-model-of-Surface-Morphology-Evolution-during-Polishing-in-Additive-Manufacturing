%% Stage 0 to Stage 1 Parameter Fitting 
%%%%%%% Asperity network %%%%%%%%%

% setModelHeightsSTG0();
% setModelRadiiSTG0();
% heightsSTG0=retrieveModelHeightsSTG0();
% radiiSTG0=retrieveModelRadiiSTG0();
params = cell(1,2); 
E = 0.2;
% dd = 0.005;
dd=0.1;
params{1} = E;
params{2} = dd;
N=size(heightsSTG0,1);
Force(1) = 44.48; % total load 
alpha(1) = 0.25; 
kappa_1(1) = 13.75;
kappa_2(1) = 2.85;
speed(1) = 0.53;
sigma(1) = 0.00085;
MRR(1) = 0;
Temp = 20*ones(N,1);  % baseline temperature
Time = 300; 
k = 2; dt = 0.2;
a_0 = 2.5;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(1);
h = zeros(N,length(Horizon));  h(:,1) = heightsSTG0;
r = zeros(N,length(Horizon));  r(:,1) = radiiSTG0*sin(pi/180);
F = zeros(N,length(Horizon));                   % Force carried by asperities
% Pressure = zeros(N, length(Horizon));           % Pressure carried by asperities
R = zeros(N,1); 
diff_heights = zeros(N,1);

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heightsSTG0);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_dV2(Force(1),r(:,k-1),h(:,k-1),params,vectorlength); %solve_for_d provided by Adithyaa
    active_nodes = find(h(:,k-1) > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    % Pressure(:,k-1) = F(:,k-1)./((r(:,k-1).^2));
    
    % Temp dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(1)*(T(:,k-1)- Temp) + kappa_1(1)*F(:, k-1) + kappa_2(1)*speed(1)); 
    
    % Sigma dynamics
    Indicator = (T(:,k-1) > (Temp));
    if (k==2)
       s(:,k) = s(:,k-1) + (dt.*s(:,k-1).*Indicator.*T(:,k-1)*(0.1)./Temp);
    else
       s(:,k) = s(:,k-1) + (dt.*s(:,k-1).*Indicator.*(T(:,k-1) - T(:,k-2))./Temp); 
    end
    
    % Differential height dynamics
    diff_heights(:,1) = (dt.*s(:,k-1).*T(:,k-1).*F(:,k-1));
    h(:,k) = h(:,k-1) - diff_heights;    
    
    % Radii update and MRR computation
    R(:,1) = h(:,k-1)./(4*r(:,k-1));
    MR_coeff = exp(-(h(:,k-1)/max(heightsSTG0).^2)).*exp(-(a_0./r(:,k-1)).^0.0833);
    r(:,k) = r(:,k-1) + (MR_coeff.*R(:,1).*(diff_heights));
    MRR(1) = MRR(1) + sum(pi.*(diff_heights.^2).*h(:,k-1).*(1 - MR_coeff)/4);
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m1 = h(:,length(Horizon));
radii_m1 = r(:,length(Horizon));
MRR(1) = MRR(1) / (250*250*5);

% height, sigma and Temp change plots
% figure
% subplot(1,3,1)
% plot(Horizon,h(active_nodes,:),'LineWidth',2)
% pub_fig;
% hold on
% title('Height change dynamics of active asperities')
% xlabel('Time (sec)')
% ylabel('Height (um)')
% 
% subplot(1,3,2)
% plot(Horizon,s(active_nodes,:),'LineWidth',2)
% pub_fig;
% hold on
% title('Sigma dynamics of asperities')
% xlabel('Time (sec)')
% ylabel('Sigma')
% 
% subplot(1,3,3) 
% plot(Horizon,T(active_nodes,:),'LineWidth',2)
% pub_fig;
% hold on
% title('Temp variation - Stage 1')
% xlabel('Time (sec)')
% ylabel('Temp (degree C)')
%% Plots
figure;
hist1=histogram(max(heights_m1)-heights_m1);
hist1.BinWidth=0.5;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,2));
hist2.BinWidth=0.5;
hist2.Normalization='probability';

%% Stage 1 - Data and Model Comparison

Table1 = readtable('matrix_stage1.csv');
data_stage1 = table2array(Table1);
data_p2p_stage1 = reshape(data_stage1, [102 32]);
data_stage1 = reshape(data_stage1, [3264 1]);
data1 = mean(data_stage1) - data_stage1;

% Stage 1 Data Statistics
max_stage1 = max(data1);
mean_stage1 = mean(data1);
stdev_stage1 = std(data1);
min_stage1 = min(data1);
Hurst_stage1 = Gen_hurst(data1);
Sa_stage1 = 0;
for i = 1: 3264
    Sa_stage1 = Sa_stage1 + ((1/3264)*(abs(data_stage1(i) - mean_stage1)));
end
P2P_stage1 = (sum(maxk(data_stage1,320,1),'all') - sum(mink(data_stage1,320,1), 'all'))/320;

% Model 1 Statistics
max_model_1 = max(heights_m1);
min_model_1 = min(heights_m1);
[Model_H1, mean_model_1, stdev_model_1, Sa_model_1, Hurst_model_1, KS_test_1, p_value_1] = surface_roughness(radii_m1, initial_asperity_radii, heights_m1, N, data_stage1, packing_density);
P2P_model_1 = (sum(maxk(heights_m1,20,1),'all') - sum(mink(heights_m1,20,1), 'all'))/20;

vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);
Fiedler = graph_evolution(x_pos, y_pos, packing_density, Force(1), radii_m1, heights_m1, heights_m0, params, vectorlength, 1);

figure
subplot(2,3,1)
histogram(data_stage1, 'Normalization', 'probability', 'BinWidth', 0.5);
title('Histogram of Stage 1 Data');
pub_fig;
ylim([0 0.4]);
xlim([0 20]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,2)
[Values_s, edges] = histcounts(data_stage1, linspace(0, 20, 30), 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values_s, centers, 'r-', 'LineWidth', 3)
title('BAC - Stage 1 Data')
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_s(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_1 - Model_H1, 'Normalization', 'probability', 'BinWidth', 0.5);
title('Histogram of Model 1 Sim');
pub_fig;
ylim([0 0.4]);
xlim([0 20]);
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')

subplot(2,3,5)
norm_heights_m1 = max_model_1 - Model_H1;
norm_heights_m1 = norm_heights_m1(norm_heights_m1 < 21);
[Values_m, edges] = histcounts(norm_heights_m1, linspace(0, 20, 30), 'Normalization', 'cdf');
centers = (edges(1:end-1)+ edges(2:end))/2;
plot(Values_m, centers, 'r-', 'LineWidth', 3);
title('BAC - Model 1 Sim');
pub_fig;
xticks([0 0.2 0.4 0.6 0.8 1]);
hold on
x = linspace(0, Values_m(1), 10);
y = [zeros(1,length(x)-1) centers(1)];
plot(x,y,'r-', 'LineWidth', 3)
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

for i = 2:1:length(Values_s)
    Values_s(i) = Values_s(i) - Values_s(i-1);
    Values_m(i) = Values_m(i) - Values_m(i-1);
end
KL_div_test_stage1 = KLDiv(Values_s, Values_m);

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min';'Mean P2P'; '(KS & KL)'};
Stage_1 = [mean_stage1; stdev_stage1; Sa_stage1; max_stage1; min_stage1; P2P_stage1; p_value_1];
Model_1 = [mean_model_1; stdev_model_1; Sa_model_1; max_model_1; min_model_1; P2P_model_1; KL_div_test_stage1];
T = table(Stage_1, Model_1, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

subplot(2,3,6)
pos = get(subplot(2,3,6), 'Position');
Model_Parameters = {'Force (N)'; 'alpha';'kappa 1'; 'kappa 2'; 'sigma'; 'λ2'; 'MRR (um/min)'};
Values_1 = [Force(1); alpha(1); kappa_1(1); kappa_2(1); sigma(1); Fiedler(1); MRR(1)];
T = table(Values_1, 'RowNames', Model_Parameters);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Model Parameters - Stage 1');
   
