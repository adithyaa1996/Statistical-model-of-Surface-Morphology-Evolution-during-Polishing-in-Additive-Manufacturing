function f=retrieveModelHeightsSTG4()
global modelheightsSTG4
f=modelheightsSTG4;