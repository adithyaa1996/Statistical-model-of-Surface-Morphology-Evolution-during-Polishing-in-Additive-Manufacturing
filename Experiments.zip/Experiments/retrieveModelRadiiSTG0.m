function f=retrieveModelRadiiSTG0()
global modelRadiiSTG0;
f=modelRadiiSTG0;
