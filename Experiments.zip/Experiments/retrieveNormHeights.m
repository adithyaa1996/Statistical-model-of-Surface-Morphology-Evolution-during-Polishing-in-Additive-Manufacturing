%% retrieve Normalised heights
function f=retrieveNormHeights()
global hghts
f=hghts;

