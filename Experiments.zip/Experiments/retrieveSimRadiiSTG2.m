function f=retrieveSimRadiiSTG2()
global simradiiSTG2
f=simradiiSTG2;