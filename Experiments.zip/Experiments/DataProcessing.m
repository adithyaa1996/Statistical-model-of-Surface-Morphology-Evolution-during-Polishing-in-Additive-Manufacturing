%% Input the data set for the different stages

hghts=zeros(102*32,26);
for i=0:25
    filename=sprintf('matrix_stage%0d.csv',i);
    hghts(:,i+1)=reshape(table2array(readtable(filename)),[102*32 1]);
end
% Normalize the data using the difference from mean
data=hghts;
hghts=repmat(mean(hghts),102*32,1)-hghts;

%% Prepare simulation
[Locations, radii_m0] = random_circle_packing_rectangle([500 500],4.51,36,true);
x_pos = Locations(:,1);
y_pos = Locations(:,2);
N = size(Locations,1);
heights_m0 = wblrnd(45,4.9,[N 1]);
asperity_area = pi * sum(radii_m0.^2);
Temp = 25*ones(N,1);
params = cell(1,2); 
E = 0.2;
dd = 0.01;
params{1} = E;
params{2} = dd;

Force = zeros(1,25);
alpha = zeros(1,25);
kappa_1 = zeros(1,25);
kappa_2 = zeros(1,25);
speed = zeros(1,25);
sigma = zeros(1,25);
rho = zeros(1,25);
% improve aesthetics of code

%% Stage 0 data and model comparison

% Stage0 statistics
data0=hghts(:,1);
data_stage0=data(:,1);
max_stage0 = max(data0);
mean_stage0 = mean(data0);
stdev_stage0 = std(data0);
min_stage0 = min(data0);
Sa_stage0 = 0;
for i = 1: 3264
    Sa_stage0 = Sa_stage0 + ((1/3264)*(abs(data0(i) - mean_stage0)));
end

% Model0 Statistics
max_model_0 = max(heights_m0);
mean_model_0 = mean(heights_m0);
stdev_model_0 = std(heights_m0);
min_model_0 = min(heights_m0);
Sa_model_0 = 0;
for i = 1: N
    Sa_model_0 = Sa_model_0 + ((1/(N))*(abs(heights_m0(i) - mean_model_0)));
end

figure
subplot(2,3,1)
histogram(data_stage0,20)
title('Histogram of Stage 0 Data');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,2)
[Values, edges] = histcounts(data_stage0, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+edges(2:end))/2;
plot(Values, centers, 'r-', 'LineWidth', 3)
title('BAC - Stage 0 Data')
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,4)
histogram(max_model_0 - heights_m0,20)
title('Histogram of Model 0 Sim');
xlabel('Heights (10^{-6} m)')
ylabel('Frequency')
pub_fig;

subplot(2,3,5)
[Values, edges] = histcounts(max_model_0 - heights_m0, 100, 'Normalization', 'cdf');
centers = (edges(1:end-1)+ edges(2:end))/2;
plot(Values, centers, 'r-', 'LineWidth', 3);
title('BAC - Model 0 Sim');
ylabel('Heights (10^{-6} m)')
xlabel('Quantile')
pub_fig;
set(gca,'ydir','reverse');

subplot(2,3,3)
pos = get(subplot(2,3,3), 'Position');
Statistics = {'Mean';'Std dev'; 'Sa value'; 'Max'; 'Min'};
Stage_0 = [mean_stage0; stdev_stage0; Sa_stage0; max_stage0; min_stage0];
Model_0 = [mean_model_0; stdev_model_0; Sa_model_0; max_model_0; min_model_0];
T = table(Stage_0, Model_0, 'RowNames', Statistics);
uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized','ColumnWidth', {70}, 'Position', pos);
pub_fig;
set(gca,'xtick',[]);
set(gca,'ytick',[]);
title('Surface Characteristics');
xlabel('All units in µm');

%% Transition from stage0 to stage 1, let dynamics flow
%%%%%%% Asperity network %%%%%%%%%
Force(1) = 44.48; % total load 
alpha(1) = 0.32; 
kappa_1(1) = 5;
kappa_2(1) = 0.5;
speed(1) = 0.53;
sigma(1) = 0.00018; 
rho(1) = 1;

Time = 300; 
k = 2; dt = 0.2;
Horizon = 0:dt:Time;
T = zeros(N,length(Horizon));  T(:,1) = Temp;
s = zeros(N,length(Horizon));  s(:,1) = sigma(1);
h = zeros(N,length(Horizon));  h(:,1) = heights_m0;
r = zeros(N,length(Horizon));  r(:,1) = radii_m0;
F = zeros(N,length(Horizon));  % Force carried by asperities

st_d_crit = zeros(length(Horizon),1);
st_active_nodes = zeros(length(Horizon),1);
vector = 0: params{2}: max(heights_m0);
vectorlength = length(vector);

for t = dt:dt:Time
    
    d_crit = solve_for_d(Force(1),r(:,k-1),h(:,k-1),params,vectorlength);
    active_nodes = find(heights_m0 > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E* sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    
    % dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(1)*(T(:,k-1)- Temp) + kappa_1(1)*F(:, k-1) + kappa_2(1)*speed(1));
    
    for i = 1:1:N
        Indicator = ((7*Temp) > T(i,k-1)) & (T(i,k-1) > (1.5*Temp));
        s(i,k) = s(i,k-1) + (dt*Indicator(i)*rho(1)*s(i,k-1)*0.01); 
        h(i,k) = h(i,k-1) - (dt*s(i,k-1)*T(i,k-1)*F(i,k-1));
        r(i,k) = r(i,k-1) + (dt*rho(1)*s(i,k-1)*T(i,k-1)*F(i,k-1)); 
    end
    
    % store
    st_d_crit(k-1) = d_crit;
    st_active_nodes(k-1) = length(active_nodes);
    k = k+1;
end

heights_m1 = h(:,length(Horizon));
radii_m1 = r(:,length(Horizon));

% height, radii and Temp change plots
figure
subplot(1,2,1)
plot(Horizon,h(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Height change dynamics of active asperities')
xlabel('Time (sec)')
ylabel('Height (um)')

subplot(1,2,2) 
plot(Horizon,T(active_nodes,:),'LineWidth',2)
pub_fig;
hold on
title('Temp variation - Stage 1')
xlabel('Time (sec)')
ylabel('Temp (degree C)')

%% draw parallels between them
figure;
histogram(hghts(:,1));
for i=1:26
    if mod(i,5)==0
        figure;
        histogram(hghts(:,i));
    end 
end
%%