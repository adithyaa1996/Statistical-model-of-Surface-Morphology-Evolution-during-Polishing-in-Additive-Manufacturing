function setSimHeights()
datastage=retrieveHeights();

pd=fitdist(datastage(:,1),'Gamma');
N=50;
global simheights
simheights=random(pd,N,1);