function f=retrieveSimHeights()
global simheights
f=simheights;

