% MValidate1 Stage 0 - Stage 1 polishing
%% Initialise heights,read heights
setGlobalHeights();
datastage=retrieveHeights();
setModelHeightsSTG0();
setModelRadiiSTG0();
% heightsSTG0=retrieveModelHeightsSTG0();
% radiiSTG0=retrieveModelRadiiSTG0();

%% Different values
% select the relative weight of KLd term as 0.7 and DeltaSA=0.1
p1=[0.6427;0.0014;0.0304]; % SA 0.7185 klD 2.3419 || PostProcessed SA 3.0530 klD 1.5555
p2=[0.7706;0.0010;0.0498]; % SA 0.5898 klD 2.5196 || PostProcessed SA 2.9803 klD 1.6436
p3=[0.8027;0.0014;0.0544]; % SA 0.3622 klD 2.4926 || PostProcessed SA 2.8530 klD 1.5429
p4=[0.8427;0.0038;0.0544]; % SA 0.5943 klD 3.3447 || PostProcessed SA 2.2262 klD 1.7869
% -----------------------------
p5=[6.7071;0.0063;3.3461]; % SA 1.3223 klD 3.4874 || PostProcessed SA 1.6887 klD 2.1558
p6=[8.7947;0.0031;2.7505]; % SA 0.7558 klD 2.9748 ** we want more points like this.
p7=[4.1938;0.0002;1.4946]; % SA 0.7859 klD 3.0667 
% -----------------------------
p8=[0.6827;0.0018;0.0304]; % SA 0.6015 klD 2.3567
% 80klD/20SA combination
p9=[1.79051191;0.00001051;0.24856651]; % SA 2.7174 klD 1.4912 *********
p10=[4.50720640;0.00052798;2.33218087]; % SA 1.6222 kld 2.0795 fval 70klD/30SA combination
% Random search initializations 
p11=[]; % SA klD fval 50klD/50SA combination 
p12=[4.98867685;0.00496892;6.01158563]; % SA klD fval 0klD/100SA combination SAmin
p13=[8.1544;0.0014;0.0309]; % SA 3.8629 klD 1.8620 fval 100/0 combination KLDmin
p13bnd=[4.23896953;0.00000954;0.72098976]; % SA 2.9470 klD 1.6446
%%---------------------------------------------
pk1=[8.1544;0.0014;0.0309]; % SA 3.3924 klD 1.8496
pk2=[6.177260;0.001592;0.085239]; % SA 2.6474 klD 1.5480 **OPT**
% We want solutions that give the right kind of T ranges
pinit=[0.25;0.00085;0.0002]; % SA 3.2445 klD 1.62242 obj 1.9468
pkT1=[0.381068;0.001463;0.000374]; % SA 3.0381 klD 1.4652 Obj 1.7798
pkT2=[0.304562;0.001827;0.000242]; % SA 2.8071 klD 1.4670 obj 1.7350 ***OPTIMAL***|| SA 2.8134 klD 0.9233

% When lambda=weight on entropy=1# c1=SA c2=KLDiv
pa100=[0.2531;0.0013;0.0004]; % SA 2.8399 klD 1.7192 works
pa100bnd=[0.3510;0.0013;0.0005]; % SA 2.9934 klD 1.5502
pa100bnd2=[0.390006;0.001374;0.000212]; % SA 3.2231 klD 1.357-1.4553 || SA 3.2245 klD 0.8832

% When lambda=weight on entropy=0
pa0=[0.0694;0.0010;0.0019]; % SA 0.7634 klD 6.7324
pa02=[0.16;0.004;0.0009]; % SA 0.5302 klD 3.1046 works
pa0bnd=[0.166409;0.006685;0.000198] % SA 0.0457 klD 3.4126 || SA 0.0480 klD 3.3373

% When lambda=weight on entropy=0.5
pa50=[0.16;0.004;0.0009]; % SA 0.5302 klD 3.1046
pa50bnd=[0.1853;0.0058;0.0002] % SA 0.4585 klD 3.0326 || SA 0.4687 klD 2.9903
%% Evaluate
[funcVal,heightsForSACalc,T]=objectiveSTG0To1Ver3(pkT2,1,1);    

%% Ideas for experiment design

% lb=[0.01;0.5;0.1;0.00001];
% ub=[20;40;10;0.04];
% lb ub pinit/2 pinit*2 result=pkT1
% lb ub pinit/10 pinit*10 result=
lb=[0.025;0.00008;0.00002];
ub=[2.5;0.008;0.002];
ObjectiveFunction = @objectiveSTG0To1;

% [xmin,fxmin]=simulatedAnnealingSolution(p6,ObjectiveFunction,lb,ub);

options = optimoptions(@simulannealbnd,'FunctionTolerance',0.0001,'MaxIterations',2000,'Display','iter');
[p,fval,exitflag,output]=simulannealbnd(ObjectiveFunction,pa02,lb,ub,options);  

%% Average Objective value
f11=zeros(10,1);klD=zeros(10,1);
for j=1:1:10
    disp(j);
    [f,h]=objectiveSTG0To1(pkT2,1,0);
    f11(j)=f;
    germa66=max(h)-h;
    % perform raid
    germa66(germa66>20)=[];
    germa=datastage(:,2);
    germa(germa>20)=[];
    klD(j)=percentDivergence(germa,germa66,70,0.1);
end
f11=mean(f11); klD=mean(klD);

%% Difference in KLDiv
upperlevel=70;intervalWidth=0.1;
kldiv=percentDivergence(datastage(:,2),max(heightsForSACalc)-heightsForSACalc,upperlevel,intervalWidth);
disp(kldiv);
%% Difference in SA values

mean_model = mean(heightsForSACalc);
M = length(heightsForSACalc);
Sa_model = (1/M)*sum(abs(heightsForSACalc - mean_model),1);% use same formula 

mean_data=mean(datastage(:,2));
Sa_data=(1/length(datastage(:,2)))*sum(abs(datastage(:,2)-mean_data),1);
diffSA=abs(Sa_model-Sa_data);
disp(diffSA);
%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:200
    disp(counter);
    lb=[0.025;0.00008;0.00002];
    ub=[2.5;0.008;0.002];
%     lb=[0;0;0];
%     lb=[4;6;1;0.001];
%     ub=[1;1;1];
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand(3,1);
    [fh,hh]=objectiveSTG0To1(xrandom,0.5,0.5);
    
    if fh<min_val
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.5;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,2));
hist2.BinWidth=0.5;
hist2.Normalization='probability';
%% Plot
figure;
germa66=max(heightsForSACalc)-heightsForSACalc;
% perform raid
germa66(germa66>20)=[];
cdf1=cdfplot(germa66);
% color1=[0 0 0];
set(cdf1,'LineWidth',5,'LineStyle','-','color','blue'); % Sigma Best Fit Stage
hold on;
germa662=datastage(:,2);
germa662(germa662>20)=[];
cdf2=cdfplot(germa662);
% color2=[0.8500, 0.3250, 0.0980];
% color2=[0 0 0];
set(cdf2,'LineWidth',5,'LineStyle','-','color','red'); % Data
xlabel('Heights (10^-6 m)','FontSize',22,'fontweight','bold');
ylabel('Quantiles','FontSize',22,'fontweight','bold');

% hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Best Fit Parameters
% % hold on;
lgd=legend([cdf2 cdf1],'Data','Model Surface','FontSize',22);
lgd.FontSize=14;
% % reposition legend
legend('Location','southwest','fontweight','bold');
title('Bearing Area Curves - Stage 1','FontSize',24)
% set(gca,'FontSize',18);
set(gca,'View',[90 -90]);
% set(gca,'ydir','reverse')
set(gca,'xdir','reverse')
yh=get(gca,'ylabel');
p34=get(yh,'position');
p34(1)=-0.4+p34(1);
set(yh,'position',p34);
box on
ax=gca;
ax.LineWidth=2;
xticks([0,5,10,15,20])
yticks([0,0.2,0.4,0.6,0.8,1])
% set a text box
annotation('textbox', [0.15, 0.3, 0.1, 0.1], 'String', ['KL Div = 0.9233' newline '\DeltaSa = 2.8134'],'LineWidth',2,'FontSize',16,'fontweight','bold');