function setModelHeightsSTG8_parametric(x)
% xsa11=[4.6749;27.0331;8.8197;0.0023];
% xsa18=[1.7249;26.8816;7.1235;0.0079];
% xsa33=[8.0481;27.4332;8.3723;0.0092];%asssumed best point
% xsa46=[4.73698226;7.38868055;1.40351507;0.00002936];
[hh,rr]=returnParametersSTG7To8(x); % is this function ready? YES

global modelradiiSTG8 % are the retrieve versions working? YES
modelradiiSTG8=rr;
% N = size(Locations,1); 
global modelheightsSTG8 % are the retrieve versions working? YES
modelheightsSTG8=hh;
