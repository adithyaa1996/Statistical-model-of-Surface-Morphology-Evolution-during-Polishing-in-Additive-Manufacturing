function f=retrieveModelHeightsSTG3()
global modelheightsSTG3
f=modelheightsSTG3;