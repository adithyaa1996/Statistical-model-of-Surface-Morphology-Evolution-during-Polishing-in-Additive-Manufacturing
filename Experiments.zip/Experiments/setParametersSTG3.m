function setParametersSTG3(x)
% xsa6=[4.3925;13.0070;1.6878;0.0087];
% [hh,rr]=returnParametersSTG0To1(x);
[hh,rr]=getParamsSTG2To3(x);

global modelradiiSTG3
modelradiiSTG3=rr;
% N = size(Locations,1); 
global modelheightsSTG3
modelheightsSTG3=hh;
