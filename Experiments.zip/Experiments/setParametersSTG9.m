function setParametersSTG9(x)
% xsa6=[4.3925;13.0070;1.6878;0.0087];
% [hh,rr]=returnParametersSTG0To1(x);
[hh,rr]=getParamsSTG8To9(x);

global modelradiiSTG9
modelradiiSTG9=rr;
% N = size(Locations,1); 
global modelheightsSTG9
modelheightsSTG9=hh;
