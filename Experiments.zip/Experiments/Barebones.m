%% generate the asperity network
%% solve for the governing differential equations
%% solve the dynamics to a satisfactory extent
%% see if for certain values of the parameters we get cycles/eddies
%% the whole process evolves on a network

%% Step1: Define the grid


%% Step2: Initialise the parameters

%% Step3: Let the dynamics evolve

%% Step4: Print figures 