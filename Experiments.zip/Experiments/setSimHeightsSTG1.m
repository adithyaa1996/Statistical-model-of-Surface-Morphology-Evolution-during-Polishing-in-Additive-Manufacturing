function setSimHeightsSTG1()
% datastage=retrieveHeights();
% datastageInv=max(datastage)-datastage;
xa1=[4.6959;19.5189;1.4134;0.0174];
% x3=[0.34;11.95;0.3;0.0057];
% x6=[0.18;11.95;1.1;0.0057];
% here's assuming the point being fed is a valid point
[h,r]=returnHeightsRadiiStg0To1(xa1);

% pd=fitdist(datastageInv(:,1)+0.000001,'Weibull');
global simradiiSTG1
simradiiSTG1=r(:,1500);
% N = size(Locations,1); 
global simheightsSTG1
simheightsSTG1=h(:,1500);
