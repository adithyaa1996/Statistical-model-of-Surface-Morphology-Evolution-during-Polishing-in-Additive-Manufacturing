hghts=zeros(102*32,26);
for i=0:25
    filename=sprintf('matrix_stage%0d.csv',i);
    hghts(:,i+1)=reshape(table2array(readtable(filename)),[102*32 1]);
end
% Normalize the data using the difference from mean
data=hghts;
hghts=repmat(mean(hghts),102*32,1)-hghts;

%% Fit probability distribution object
pd=fitdist(data(:,1),'Gamma');
