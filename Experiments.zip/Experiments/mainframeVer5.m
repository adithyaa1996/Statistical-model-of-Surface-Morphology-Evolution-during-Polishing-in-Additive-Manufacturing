%% mainframe DO NOT EXECUTE AFTER FIRST TIME
% setGlobalHeights(); % inputs all the data from csv
% setSimHeights(); % finalises initial heights for model. Uses a gamma fit on stage 0 data, then samples at random from fit


%% Run file
x0=[0.32;5;0.5;0.0005];% alpha, kappa_1,kappa_2,sigma
% fh=evaluateObjectiveVer4(x);
ObjectiveFunction = @evaluateObjectiveVer5;
% x0 = [0.5 0.5];   % Starting point
% rng default % For reproducibility
lb=[0.01;0.5;0.1;0.00001];
ub=[2;20;5;0.01];
% options = optimoptions(@simulannealbnd,'MaxIterations',2,'FunctionTolerance',0.01);
% [x,fval,exitFlag,output] = simulannealbnd(ObjectiveFunction,x0,lb,ub); 
[xmin,fxmin]=simulatedAnnealingSolution(x0,ObjectiveFunction,lb,ub);

%% Evaluate objective
for i=1:1:10    
    fh2=evaluateObjectiveVer5(x1);
    disp(fh2);
end
%% Experiment
x1=[0.3;3;0.7;0.0009];
x0=[0.32;5;0.5;0.0005];
x2=[0.32;5;0.5;0.0005];
x3=[0.3,1,1.9,0.001];
% x4=xmin;
x5=[0.05;4;2.4;0.0045];
x6=[0.14;10.5;1.3;0.0062];
x7=[0.75;4.5;0.4;0.0056];
% [fh3,h3]=evaluateObjectiveVer5(x7);
x8=[0.32;8;0.5;0.0027];
[fh4,h4]=evaluateObjectiveVer6(x8);
