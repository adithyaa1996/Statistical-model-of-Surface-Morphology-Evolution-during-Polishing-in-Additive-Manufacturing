function f=retrieveModelRadiiSTG1()
global modelradiiSTG1;
f=modelradiiSTG1;
