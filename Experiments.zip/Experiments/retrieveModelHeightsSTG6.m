function f=retrieveModelHeightsSTG6()
global modelheightsSTG6
f=modelheightsSTG6;