function f=retrieveModelHeightsSTG5()
global modelheightsSTG5
f=modelheightsSTG5;