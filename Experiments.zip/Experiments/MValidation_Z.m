
%% model validation stage0To1  version Z
% two parameter search alpha and sigma
% find the optimal value of alpha and sigma when minimizing
% a) the entropy
% b) the SA difference
% c) convex combination of the two (try out different things)
%% So where do we start from
% Stage0-stage1
% Step1: Initialise heights, read heights
% Step2: Apply modified dynamics
% Step3: Define the objective for the new height functions
% Step4: Find objective value

%% Initialise heights,read heights
setGlobalHeights();
datastage=retrieveHeights();
% % % mean 24.3355 std 9.7912
setModelHeightsSTG0();
setModelRadiiSTG0();
% heightsSTG0=retrieveModelHeightsSTG0();
% radiiSTG0=retrieveModelRadiiSTG0();
%% Different values
% Solve for Entropy 
sial1=[1.0122;0.0031]; % sa 3.2982 klD 1.6067
% Solve for Del_SA
sial2=[1.1904;0.0164]; % sa 0.0173 klD 3.6515
% Solve for convex comb SA and Entropy (10/90)
sial3=[4.1200;0.0045]; % sa 2.8863 klD 1.6459
% Solve for convex comb SA and Entropy (30/70)
sial4=[5.9519;0.0067]; % sa 2.2473 klD 1.7789 ********
%% Evaluate
[funcVal,heightsForSACalc]=evalObjectiveStage0To1V2_Z(sial4,1,1);
%%
[funcValUF,heightsForSACalcUF]=evalObjectiveStage0To1V2_1(xsa6);
%% Ideas for experiment design

lb=[0.01;0.5;0.1;0.00001];
ub=[20;40;10;0.04];
ObjectiveFunction = @evalObjectiveStage0To1V2_1;

[xmin,fxmin]=simulatedAnnealingSolution(xb5sa1_cand,ObjectiveFunction,lb,ub);

%% Average Objective value
f11=zeros(20,1);klD=zeros(20,1);
for j=1:1:20
    disp(j);
    [f,h]=evalObjectiveStage0To1V2_Z(sial1,1,0);
    f11(j)=f;
    klD(j)=percentDivergence(datastage(:,2),max(h)-h,70,0.1);
end
f11=mean(f11); klD=mean(klD);

%% Difference in KLDiv
upperlevel=70;intervalWidth=0.1;
kldiv=percentDivergence(datastage(:,2),max(heightsForSACalc)-heightsForSACalc,upperlevel,intervalWidth);
disp(kldiv);
%% Difference in SA values

mean_model = mean(heightsForSACalc);
M = length(heightsForSACalc);
Sa_model = (1/M)*sum(abs(heightsForSACalc - mean_model),1);% use same formula 

mean_data=mean(datastage(:,2));
Sa_data=(1/length(datastage(:,2)))*sum(abs(datastage(:,2)-mean_data),1);
diffSA=abs(Sa_model-Sa_data);
disp(diffSA);
%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:2000
    disp(counter);
    lb=[1;0.00000001];
%     lb=[4;6;1;0.001];
    ub=[10;1];
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand(2,1);
    [fh,hh]=evalObjectiveStage0To1V2_Z(xrandom,0.3,0.7);
%     fh=zeros(10,1);
%     for j=1:1:10
%         fh(j)=evalObjectiveStage0To1V2_2(xrandom,1,2);
%     end
    
%     fh=mean(fh);
%     [fh,hh]=evalObjectiveStage0To1V2_2(xrandom,1,1);
    
    if fh<min_val
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.5;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,2));
hist2.BinWidth=0.5;
hist2.Normalization='probability';
%% Plot
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
color1=[0 0 0];
set(cdf1,'LineWidth',3.5,'LineStyle','-','color',color1); % Sigma Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,2));
% color2=[0.8500, 0.3250, 0.0980];
color2=[0 0 0];
set(cdf2,'LineWidth',3,'LineStyle','--','color',color2); % Data
xlabel('x','FontSize',18);
ylabel('Cumulative Probability','FontSize',18);

% hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Best Fit Parameters
% % hold on;
% lgd=legend('Simulation','Data');
% lgd.FontSize=18;
% % reposition legend
% legend('Location','southeast');
title('')
set(gca,'FontSize',14);
yh=get(gca,'ylabel');
p34=get(yh,'position');
p34(1)=-0.4+p34(1);
set(yh,'position',p34);

% set a text box
annotation('textbox', [0.5, 0.6, 0.1, 0.1], 'String', 'KLdiv = 1.78    \DeltaSa = 2.25','FontSize',16)