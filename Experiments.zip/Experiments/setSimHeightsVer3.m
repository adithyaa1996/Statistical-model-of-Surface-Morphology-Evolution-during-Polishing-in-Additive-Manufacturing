function setSimHeightsVer3()
datastage=retrieveHeights();
datastageInv=max(datastage)-datastage;
pd=fitdist(datastageInv(:,1)+0.000001,'Weibull');
global simradiiCP
[Locations, simradiiCP] = random_circle_packing_rectangle([250 250],3.14,25,true);
N = size(Locations,1); 
global simheightsCP
simheightsCP=random(pd,N,1);
