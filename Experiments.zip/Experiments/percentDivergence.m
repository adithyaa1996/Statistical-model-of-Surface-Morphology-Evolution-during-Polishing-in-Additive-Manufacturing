function f=percentDivergence(datastage1,simheights,upperlevel,intervalWidth)
%% Documentation
% This function calculates a KLdivergence inspired measure that quantifies
% the distance between two distributions. datastage1 is the stage1 data
% obtained from experiments. simheights is the heights obtained by
% simulation. binsize is the number of bins used
% -------------------------------------------------------------------------
%% Arrange in bins
x=0:intervalWidth:upperlevel;
epsilon=0.000001; % reasonable error estimate used to handle 0/0

Px=histcounts(datastage1,x)/length(datastage1);
Pxplus=histcounts(datastage1,x)/length(datastage1)+epsilon;

Qx=histcounts(simheights,x)/length(simheights);
Qxplus=histcounts(simheights,x)/length(simheights)+epsilon;

%% Compute measure, Jensen Shannon Divergence
f=sum(Px.*(log2(Pxplus)-log2(Qxplus)))+sum(Qx.*(log2(Qxplus)-log2(Pxplus)));
f=f/2;
% f=f+0.5*abs(std(simheights)-std(datastage1)); % added the abs of difference in sd


