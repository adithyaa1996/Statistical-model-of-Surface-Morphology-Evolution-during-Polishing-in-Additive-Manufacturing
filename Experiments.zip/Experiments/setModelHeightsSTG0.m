function setModelHeightsSTG0()
global modelHeightsSTG0
modelHeightsSTG0=load('Initial_heights_Stage0.mat').heights_m0;

