function f=retrieveModelHeightsSTG7()
global modelheightsSTG7
f=modelheightsSTG7;