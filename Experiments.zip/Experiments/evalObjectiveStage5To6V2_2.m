function [f,heightsForSACalc]=evalObjectiveStage5To6V2_2(x,c1,c2)

datastage=retrieveHeights();
heightsSTG5=retrieveModelHeightsSTG5(); % heights_m0
radiiSTG5=retrieveModelRadiiSTG5(); % initial_surface_radii
N=size(heightsSTG5,1);
params = cell(1,2); 
% E = 1; dd = 0.01;
E=0.2;dd=0.1;
params{1} = E; params{2} = dd;
% Force = 1;
Force=44.48;
alpha = x(1);kappa_1 = x(2);kappa_2 = x(3);sigma = x(4);
speed = 0.53;
rho = 1;  
a_0=2.5;
Time=900;
dt=0.2;
Horizon=0:dt:Time;

% initialise evolution parameters
T=zeros(N,length(Horizon)); T(:,1)=20*ones(N,1);Temp=20*ones(N,1);
h=zeros(N,length(Horizon)); h(:,1)=heightsSTG5;
r=zeros(N,length(Horizon)); r(:,1)=radiiSTG5;
s=zeros(N,length(Horizon)); s(:,1)=sigma*ones(N,1);
k = 2;
F=zeros(N,length(Horizon));
vector = 0: params{2}: max(heightsSTG5);
vectorlength = length(vector);
for t = dt:dt:Time
    
    d_crit = solve_for_dV2(Force(1),r(:,k-1),h(:,k-1),params,vectorlength); %solve_for_d provided by Adithyaa
    active_nodes = find(h(:,k-1) > d_crit); % load bearing asperities
    F(active_nodes, k) = (2/3)*E*sqrt(abs(r(active_nodes,k-1))).*((abs(h(active_nodes,k-1) - d_crit.*ones(length(active_nodes),1))).^(3/2));   % force carried by each node. 
    % Pressure(:,k-1) = F(:,k-1)./((r(:,k-1).^2));
    
    if ~isreal(F)
        f=100000;
        heightsForSACalc=h(:,k-1);
        return;
    end
    
    % Temp dynamics
    T(:,k) = T(:,k-1) + dt*(-alpha(1)*(T(:,k-1)- Temp) + kappa_1(1)*F(:, k-1) + kappa_2(1)*speed(1)); 
    if min(T(:,k))<=0
        f=100000;
        heightsForSACalc=h(:,k-1);
        return;
    end
    
    % Sigma dynamics
    Indicator = (T(:,k-1) > (Temp));
    if (k==2)
       s(:,k) = s(:,k-1) + (dt.*s(:,k-1).*Indicator.*T(:,k-1)*(0.1)./Temp);
    else
       s(:,k) = s(:,k-1) + (dt.*s(:,k-1).*Indicator.*(T(:,k-1) - T(:,k-2))./Temp); 
    end
    
    % Differential height dynamics
    diff_heights(:,1) = (dt.*s(:,k-1).*T(:,k-1).*F(:,k-1));
    h(:,k) = h(:,k-1) - diff_heights;    
    
    if min(h(:,k))<=0.0001
        f=100000;
        heightsForSACalc=h(:,k-1);
        return;
    end
        
    % Radii update and MRR computation
    R(:,1) = h(:,k-1)./(4*r(:,k-1));
    MR_coeff = exp(-(h(:,k-1)/max(heightsSTG5).^2)).*exp(-(a_0./r(:,k-1)).^0.0833);
    r(:,k) = r(:,k-1) + (MR_coeff.*R(:,1).*(diff_heights));
%     MRR(1) = MRR(1) + sum(pi.*(diff_heights.^2).*h(:,k-1).*(1 - MR_coeff)/4);
    
    k = k+1;
end

% % design objective
% sa_data=(1/N)*sum(abs(datastage(:,2) - mean(datastage(:,2))));
% sa_model=surface_roughnessV2(r(:,k-1),h(:,k-1));
upperlevel=60;intervalWidth=0.05;
heightsForSACalc=surfaceRoughnessHeights(r(:,k-1),h(:,k-1));

mean_model = mean(heightsForSACalc);
M = length(heightsForSACalc);
Sa_model = (1/M)*sum(abs(heightsForSACalc - mean_model),1);% use same formula 

mean_data=mean(datastage(:,7)); %%stage6 data
Sa_data=(1/length(datastage(:,7)))*sum(abs(datastage(:,7)-mean_data),1);
kldiv=percentDivergence(datastage(:,7),max(heightsForSACalc)-heightsForSACalc,upperlevel,intervalWidth);
% 10*abs(kldiv-0.15);
% f=abs(sa_data-sa_model)+abs(kldiv-0.15)*10;
f=c1*abs(Sa_model-Sa_data)+c2*abs(kldiv);
% +10*abs(kldiv-0.15);
