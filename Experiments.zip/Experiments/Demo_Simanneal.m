ObjectiveFunction = @simple_objective;
x0 = [0.5; 0.5];   % Starting point
% rng default % For reproducibility
% options=optimoptions(@simulannealbnd,'MaxIterations',100000,'FunctionTolerance',0.000000001);
% [x,fval,exitFlag,output] = simulannealbnd(ObjectiveFunction,x0);
lb=[-2 ;-2];
ub=[3 ;3];
[xmin,fxmin]=simulatedAnnealingSolution(x0,ObjectiveFunction,lb,ub);
