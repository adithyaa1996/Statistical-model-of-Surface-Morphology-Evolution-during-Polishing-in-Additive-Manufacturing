%% mainframe DO NOT EXECUTE AFTER FIRST TIME
% setGlobalHeights(); % inputs all the data from csv
% setSimHeights(); % finalises initial heights for model. Uses a gamma fit on stage 0 data, then samples at random from fit
%% Run file
x=[0.32;5;0.5;0.0001];% alpha, kappa_1,kappa_2,sigma
[fh,T,h,r]=evaluateObjectiveVer3(x);
% ObjectiveFunction = @simple_objective;
% x0 = [0.5 0.5];   % Starting point
% rng default % For reproducibility
% [x,fval,exitFlag,output] = simulannealbnd(ObjectiveFunction,x0);