function f=retrieveModelHeightsSTG8()
global modelheightsSTG8
f=modelheightsSTG8;