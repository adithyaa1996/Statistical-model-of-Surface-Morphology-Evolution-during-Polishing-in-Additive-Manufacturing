% MValidate5 Stage 6 - Stage 7 polishing

%% Initialise heights,read heights EN 70/ SA 30
 
%% Initialise heights, read heights EN 80/ SA 20
setParametersSTG1(pkT2);
setParametersSTG2(pkT6);
setParametersSTG3(pkT8); 
setParametersSTG4(pkT10);
setParametersSTG5(pkT11);
setParametersSTG6(pkT13);
%% Different values
% 80-20 Evaluation
pkT14=[1.864852;0.000163;0.001803]; % SA 2.7394 klD 1.4938
pkT15=[0.329356;0.000116;0.000687]; % SA 2.7394 klD 1.4938 
pkT16=[0.413329;0.000083;0.001472]; % SA 2.7394 klD 1.4938 ** OPTIMAL **
%% Evaluate
[funcVal,heightsForSACalc]=objectiveSTG6To7(pkT15,1,1); 

%% Ideas for experiment design

% lb=[0.01;0.5;0.1;0.00001];
% ub=[20;40;10;0.04];
% 
% lb=[0;0;0];
% ub=[10;1;10];

lb=[0.025;0.00008;0.00002];
ub=[2.5;0.008;0.002];
ObjectiveFunction = @objectiveSTG6To7;

% [xmin,fxmin]=simulatedAnnealingSolution(p6,ObjectiveFunction,lb,ub);

options = optimoptions(@simulannealbnd,'FunctionTolerance',0.0001,'MaxIterations',3000,'Display','iter');
[p,fval,exitflag,output]=simulannealbnd(ObjectiveFunction,pkT15,lb,ub,options);  

%% Average Objective value
f11=zeros(20,1);klD=zeros(20,1);
for j=1:1:20
    disp(j);
    [f,h]=objectiveSTG6To7(pkT14,1,0);
    f11(j)=f;
    klD(j)=percentDivergence(datastage(:,8),max(h)-h,70,0.1);
end
f11=mean(f11); klD=mean(klD);


%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:30000
    disp(counter);
%     lb=[0;0;0];
% %     lb=[4;6;1;0.001];
%     ub=[10;1;10];
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];

    lb=[0.025;0.00008;0.00002];
    ub=[2.5;0.008;0.002];
    xrandom=lb+(ub-lb).*rand(3,1);
    [fh,hh]=objectiveSTG6To7(xrandom,0.2,0.8);
    
    if fh<min_val
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.5;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,8));
hist2.BinWidth=0.5;
hist2.Normalization='probability';
%% Plot
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
color1=[0 0 0];
set(cdf1,'LineWidth',3.5,'LineStyle','-','color',color1); % Sigma Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,8));
% color2=[0.8500, 0.3250, 0.0980];
color2=[0 0 0];
set(cdf2,'LineWidth',3,'LineStyle','--','color',color2); % Data
xlabel('x','FontSize',18);
ylabel('Cumulative Probability','FontSize',18);

% hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Best Fit Parameters
% % hold on;
% lgd=legend('Simulation','Data');
% lgd.FontSize=18;
% % reposition legend
% legend('Location','southeast');
title('')
set(gca,'FontSize',14);
yh=get(gca,'ylabel');
p34=get(yh,'position');
p34(1)=-0.4+p34(1);
set(yh,'position',p34);
annotation('textbox',  [0.5, 0.6, 0.1, 0.1], 'String', 'KLdiv = 1.49   \DeltaSa = 2.73','FontSize',16)
% set a text box
% annotation('textbox',  [0.5, 0.6, 0.1, 0.1], 'String', 'KLdiv = 3.65
% \DeltaSa = 2.22','FontSize',16)s