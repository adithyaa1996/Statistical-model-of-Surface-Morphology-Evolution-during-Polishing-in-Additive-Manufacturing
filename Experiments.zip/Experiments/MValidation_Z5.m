%% So where do we start from
% Stage0-stage1
% Step1: Initialise heights, read heights
% Step2: Apply modified dynamics
% Step3: Define the objective for the new height functions
% Step4: Find objective value

%% Initialise heights,read heights EN
setModelHeightsSTG1_parametric([sial1(1);1;1;sial1(2)]); %
setModelHeightsSTG2_parametric([sial5(1);1;1;sial5(2)]); % 
setModelHeightsSTG3_parametric([sial10(1);1;1;sial10(2)]); % Executed

%% Initialise heights,read heights SA
setModelHeightsSTG1_parametric([sial2(1);1;1;sial2(2)]); % 
setModelHeightsSTG2_parametric([sial6b(1);1;1;sial6b(2)]); % 
setModelHeightsSTG3_parametric([sial11(1);1;1;sial11(2)]); % Executed
%% Initialise heights,read heights SA+EN (10/90)
setModelHeightsSTG1_parametric([sial3(1);1;1;sial3(2)]); % 
setModelHeightsSTG2_parametric([sial7b(1);1;1;sial7b(2)]); % 
setModelHeightsSTG3_parametric([sial12(1);1;1;sial12(2)]); % Executed
%% Initialise heights,read heights SA+EN (30/70) *** Only perform this
setModelHeightsSTG1_parametric([sial4(1);1;1;sial4(2)]); % 
setModelHeightsSTG2_parametric([sial8(1);1;1;sial8(2)]); %
setModelHeightsSTG3_parametric([sial13(1);1;1;sial13(2)]); % Executed
setModelHeightsSTG4_parametric([sial17(1);1;1;sial17(2)]);

%% Different values (Replace)
% Solve for Entropy 70 SA 30
sial18=[4.6856;0.0003]; % sa 2.60584237 kld 3.99708548
sial19=[3.1568;0.0004]; % ******** sa 2.60552595 klD 3.48051304
sial18a=[8.82371654;0.00047434]; % sa 2.60532961 klD 3.21993644 better solution
sial18b=[];
%% Evaluate
[funcVal,heightsForSACalc]=evalObjectiveStage4To5V2_Z(sial19,0.3,0.7);
%%
setModelHeightsSTG1();
setModelHeightsSTG2();
setModelHeightsSTG3();
xta1=[4.7101;23.5887;6.5008;0.0070]; %(sa 2.2327 klD 3.8623)
[funcValUF,heightsForSACalcUF]=evalObjectiveStage3To4V2_2(xta1,1,1);
%% Ideas for experiment design
lb=[0.01;0.5;0.1;0.00001];
ub=[20;40;10;0.04];
ObjectiveFunction = @evalObjectiveStage3To4V2_2;
[xmin,fxmin]=simulatedAnnealingSolution(xsa33,ObjectiveFunction,lb,ub); 

%% Average Objective value
f11=zeros(20,1);klD=zeros(20,1);
for j=1:1:20
    disp(j);
    [f,h]=evalObjectiveStage4To5V2_Z(sial19,1,0);
    f11(j)=f;
    klD(j)=percentDivergence(datastage(:,6),max(h)-h,70,0.1);
end
f11=mean(f11); klD=mean(klD);
 
%% Random Search Stochastic edition
min_val=100000;
for counter=1:1:90000
    disp(counter);
    lb=[1;0.00000001];
%     lb=[4;6;1;0.001];
    ub=[10;1];
%     ub=[200;300;100;10];
%     ub=[9;28;9;0.02];
    xrandom=lb+(ub-lb).*rand(2,1);
    [fh,hh]=evalObjectiveStage4To5V2_Z(xrandom,0.3,0.7);
    
    if fh<min_val 
        min_val=fh;
        min_x=xrandom;
        disp(min_x);
    end
    disp(min_val)
end
disp(min_val);
disp(min_x);
%% Plot
figure;
hist1=histogram(max(heightsForSACalc)-heightsForSACalc);
hist1.BinWidth=0.3;
hist1.Normalization='probability';
hold;
hist2=histogram(datastage(:,6));
hist2.BinWidth=0.3;
hist2.Normalization='probability';
%%
figure;
cdf1=cdfplot(max(heightsForSACalc)-heightsForSACalc);
set(cdf1,'LineWidth',2,'LineStyle','-'); % Model Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,6));
color2=[0.8500, 0.3250, 0.0980];
set(cdf2,'LineWidth',2,'LineStyle','--','color',color2); % Data
hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Unified Parameters
% hold on;
legend('Simulation','Data');

%% Plot overall
plot([5.9519 4.5928 3.1029 5.2017],[0.0067 0.0059 0.0026 0.0160])

%% Graphics module
figure;
germa66=max(heightsForSACalc)-heightsForSACalc;
% perform raid
germa66(germa66>3)=[];

cdf1=cdfplot(germa66);
color1=[0 0 0];
set(cdf1,'LineWidth',3.5,'LineStyle','-','color',color1); % Sigma Best Fit Stage
hold on;
cdf2=cdfplot(datastage(:,6));
% color2=[0.8500, 0.3250, 0.0980];
color2=[0 0 0];
set(cdf2,'LineWidth',3,'LineStyle','--','color',color2); % Data
xlabel('x','FontSize',18);
ylabel('Cumulative Probability','FontSize',18);


% set a text box
annotation('textbox', [0.5, 0.6, 0.1, 0.1], 'String', 'KLdiv = 3.48    \DeltaSa = 2.60','FontSize',16)

% hold on;
% cdf3=cdfplot(max(heightsForSACalcUF)-heightsForSACalcUF);
% set(cdf3,'LineWidth',2,'LineStyle',':','color','blue');% Best Fit Parameters
% % hold on;
% lgd=legend('Simulation','Data');
% lgd.FontSize=18;
title('')
set(gca,'FontSize',14);
% yh=get(gca,'ylabel');
% p34=get(yh,'position');
% p34(1)=-0.4+p34(1);
% set(yh,'position',p34);
