function f=retrieveModelRadiiSTG8()
global modelradiiSTG8;
f=modelradiiSTG8;
