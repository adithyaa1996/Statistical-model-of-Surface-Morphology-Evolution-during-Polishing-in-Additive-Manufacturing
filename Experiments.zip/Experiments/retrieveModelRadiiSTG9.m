function f=retrieveModelRadiiSTG9()
global modelradiiSTG9;
f=modelradiiSTG9;
