function f=retrieveGlobalHeights()
global hghts;
f=hghts;
