function f=retrieveModelHeightsSTG0()
global modelHeightsSTG0;
f=modelHeightsSTG0;
